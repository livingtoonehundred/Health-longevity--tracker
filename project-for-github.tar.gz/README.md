# Health & Longevity Tracker

A comprehensive health and wellness application that gamifies positive lifestyle choices through an interactive life expectancy tracking system.

## Features
- AI-powered nutrition scoring
- Life expectancy countdown clock
- Exercise and sleep tracking
- Time-restricted eating monitoring
- Educational health content
- Personalized recommendations

## Deployment to Vercel

1. Upload all these files to a new GitHub repository
2. Connect your GitHub account to Vercel at vercel.com
3. Import your repository
4. Add these environment variables:
   - `DATABASE_URL`: Your PostgreSQL database connection string
   - `ANTHROPIC_API_KEY`: Your Anthropic API key for AI features

## Local Development

```bash
npm install
npm run dev
```

## Tech Stack
- Frontend: React + TypeScript + Tailwind CSS
- Backend: Express.js + TypeScript
- Database: PostgreSQL with Drizzle ORM
- AI: Anthropic Claude for health insights