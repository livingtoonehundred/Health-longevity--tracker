import { pgTable, text, serial, integer, boolean, timestamp, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  name: text("name").notNull(),
  age: integer("age").notNull(),
  educationLevel: text("education_level").notNull(), // basic, intermediate, advanced
  baseLifeExpectancy: decimal("base_life_expectancy", { precision: 4, scale: 1 }).notNull(),
  currentLifeExpectancy: decimal("current_life_expectancy", { precision: 8, scale: 4 }).notNull(),
  totalLifeExtension: decimal("total_life_extension", { precision: 4, scale: 1 }).notNull().default("0"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const foodEntries = pgTable("food_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  foodName: text("food_name").notNull(),
  mealType: text("meal_type").notNull(), // breakfast, lunch, dinner, snack
  nutritionScore: integer("nutrition_score").notNull(), // 1-100
  lifeImpactHours: decimal("life_impact_hours", { precision: 4, scale: 2 }).notNull(),
  explanation: text("explanation").notNull(),
  loggedAt: timestamp("logged_at").notNull().defaultNow(),
});

export const exerciseEntries = pgTable("exercise_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  exerciseType: text("exercise_type").notNull(),
  duration: integer("duration").notNull(), // minutes
  intensity: text("intensity").notNull(), // low, medium, high
  caloriesBurned: integer("calories_burned").notNull(),
  lifeImpactHours: decimal("life_impact_hours", { precision: 4, scale: 2 }).notNull(),
  explanation: text("explanation").notNull(),
  loggedAt: timestamp("logged_at").notNull().defaultNow(),
});

export const sleepEntries = pgTable("sleep_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  duration: decimal("duration", { precision: 3, scale: 1 }).notNull(), // hours
  quality: integer("quality").notNull(), // 1-5 stars
  sleepTime: text("sleep_time"),
  wakeTime: text("wake_time"),
  lifeImpactHours: decimal("life_impact_hours", { precision: 4, scale: 2 }).notNull(),
  explanation: text("explanation").notNull(),
  loggedAt: timestamp("logged_at").notNull().defaultNow(),
});

export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  achievedAt: timestamp("achieved_at").notNull().defaultNow(),
});

export const educationalContent = pgTable("educational_content", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  content: text("content").notNull(),
  category: text("category").notNull(), // nutrition, exercise, sleep
  educationLevel: text("education_level").notNull(), // basic, intermediate, advanced
  icon: text("icon").notNull(),
  readTime: integer("read_time").notNull(), // minutes
});

export const eatingWindows = pgTable("eating_windows", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  firstMealTime: text("first_meal_time").notNull(),
  lastMealTime: text("last_meal_time").notNull(),
  fastingHours: text("fasting_hours").notNull(),
  eatingWindowHours: text("eating_window_hours").notNull(),
  lifeImpactHours: text("life_impact_hours").notNull(),
  explanation: text("explanation").notNull(),
  loggedAt: timestamp("logged_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertFoodEntrySchema = createInsertSchema(foodEntries).omit({
  id: true,
  loggedAt: true,
  lifeImpactHours: true,
  explanation: true,
});

export const insertExerciseEntrySchema = createInsertSchema(exerciseEntries).omit({
  id: true,
  loggedAt: true,
  lifeImpactHours: true,
  explanation: true,
});

export const insertSleepEntrySchema = createInsertSchema(sleepEntries).omit({
  id: true,
  loggedAt: true,
  lifeImpactHours: true,
  explanation: true,
});

export const insertEatingWindowSchema = createInsertSchema(eatingWindows).omit({
  id: true,
  userId: true,
  loggedAt: true,
  lifeImpactHours: true,
  explanation: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type FoodEntry = typeof foodEntries.$inferSelect;
export type InsertFoodEntry = z.infer<typeof insertFoodEntrySchema>;
export type ExerciseEntry = typeof exerciseEntries.$inferSelect;
export type InsertExerciseEntry = z.infer<typeof insertExerciseEntrySchema>;
export type SleepEntry = typeof sleepEntries.$inferSelect;
export type InsertSleepEntry = z.infer<typeof insertSleepEntrySchema>;
export type EatingWindow = typeof eatingWindows.$inferSelect;
export type InsertEatingWindow = z.infer<typeof insertEatingWindowSchema>;
export type Achievement = typeof achievements.$inferSelect;
export type EducationalContent = typeof educationalContent.$inferSelect;
