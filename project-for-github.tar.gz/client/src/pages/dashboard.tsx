import { Header } from "@/components/header";
import { HealthRiskHeader } from "@/components/health-risk-header";
import { LongevityTracker } from "@/components/longevity-tracker";
import { CountdownClock } from "@/components/countdown-clock";
import { FoodTracking } from "@/components/food-tracking";
import { EatingWindowTracking } from "@/components/eating-window-tracking";
import { ExerciseTracking } from "@/components/exercise-tracking";
import { SleepTracking } from "@/components/sleep-tracking";

import { Recommendations } from "@/components/recommendations";
import { Achievements } from "@/components/achievements";
import { EducationalSection } from "@/components/educational-section";
import { FloatingActionButton } from "@/components/floating-action-button";
import { OnboardingSurvey } from "@/components/onboarding-survey";
import { LongevityToolkit } from "@/components/longevity-toolkit";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowUp, Check, Apple, Dumbbell, Moon, UserPlus } from "lucide-react";
import { useState } from "react";

interface DashboardStats {
  nutritionScore: number;
  exerciseMinutes: number;
  sleepQuality: number;
  weeklyExerciseMinutes: number;
  weeklyCaloriesBurned: number;
}

export default function Dashboard() {
  const [showOnboarding, setShowOnboarding] = useState(false);
  
  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  const handleOnboardingComplete = async (data: any) => {
    try {
      await fetch('/api/user/onboarding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      
      setShowOnboarding(false);
      // Refresh to show personalized data
      window.location.reload();
    } catch (error) {
      console.error('Failed to save onboarding data:', error);
    }
  };

  if (statsLoading) {
    return <div className="min-h-screen bg-gray-50">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50 font-sans">
      <Header />
      <HealthRiskHeader />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6 lg:py-8">
        {/* Welcome Banner with Onboarding Button */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-200">
          <div>
            <h2 className="text-lg font-semibold text-gray-900">Welcome to LifeSpan+</h2>
            <p className="text-sm text-gray-600 mt-1">Track your health choices and extend your longevity</p>
          </div>
          <Button 
            onClick={() => setShowOnboarding(true)}
            className="mt-3 sm:mt-0"
            variant="outline"
          >
            <UserPlus className="w-4 h-4 mr-2" />
            Complete Setup Survey
          </Button>
        </div>

        {/* Longevity Tracker Section */}
        <section className="mb-8">
          <LongevityTracker />
        </section>

        {/* Quick Stats Grid */}
        <section className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          <Card className="shadow-sm border border-gray-200">
            <CardContent className="p-4 sm:p-6">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <p className="text-xs sm:text-sm text-gray-500">Today's Nutrition</p>
                  <p className="text-xl sm:text-2xl font-bold text-gray-900">{stats?.nutritionScore || 0}</p>
                  <p className="text-xs text-success mt-1 flex items-center">
                    <ArrowUp className="w-3 h-3 mr-1" />
                    <span className="hidden sm:inline">Great choices today!</span>
                    <span className="sm:hidden">Good!</span>
                  </p>
                </div>
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <Apple className="text-primary w-4 h-4 sm:w-5 sm:h-5" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-sm border border-gray-200">
            <CardContent className="p-4 sm:p-6">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <p className="text-xs sm:text-sm text-gray-500">Exercise Min</p>
                  <p className="text-xl sm:text-2xl font-bold text-gray-900">{stats?.exerciseMinutes || 0}</p>
                  <p className="text-xs text-success mt-1 flex items-center">
                    <ArrowUp className="w-3 h-3 mr-1" />
                    Goal: 30 min
                  </p>
                </div>
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <Dumbbell className="text-secondary w-4 h-4 sm:w-5 sm:h-5" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-sm border border-gray-200">
            <CardContent className="p-4 sm:p-6">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <p className="text-xs sm:text-sm text-gray-500">Sleep Quality</p>
                  <p className="text-xl sm:text-2xl font-bold text-gray-900">{stats?.sleepQuality || 0}%</p>
                  <p className="text-xs text-success mt-1 flex items-center">
                    <Check className="w-3 h-3 mr-1" />
                    <span className="hidden sm:inline">Excellent!</span>
                    <span className="sm:hidden">Good!</span>
                  </p>
                </div>
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <Moon className="text-purple-600 w-4 h-4 sm:w-5 sm:h-5" />
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Countdown Clock - Prominent Feature */}
        <div className="mb-6">
          <CountdownClock />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 lg:gap-8">
          {/* Left Column: Food & Exercise Tracking */}
          <div className="lg:col-span-2 space-y-4 lg:space-y-8">
            <FoodTracking />
            <EatingWindowTracking />
            <ExerciseTracking weeklyStats={{ 
              totalMinutes: stats?.weeklyExerciseMinutes || 0, 
              totalCalories: stats?.weeklyCaloriesBurned || 0 
            }} />
          </div>

          {/* Right Column: Sleep, Education & Recommendations */}
          <div className="space-y-4 lg:space-y-8">
            <SleepTracking />
            <Recommendations />
            <Achievements />
          </div>
        </div>

        {/* Tabs Section: Educational Content & Longevity Toolkit */}
        <Tabs defaultValue="education" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="education">Educational Content</TabsTrigger>
            <TabsTrigger value="toolkit">Longevity Toolkit</TabsTrigger>
          </TabsList>
          <TabsContent value="education" className="mt-6">
            <EducationalSection />
          </TabsContent>
          <TabsContent value="toolkit" className="mt-6">
            <LongevityToolkit />
          </TabsContent>
        </Tabs>
      </main>

      <FloatingActionButton />
      
      {/* Onboarding Survey */}
      <OnboardingSurvey 
        open={showOnboarding} 
        onComplete={handleOnboardingComplete}
      />
    </div>
  );
}
