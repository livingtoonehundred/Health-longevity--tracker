import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface OnboardingSurveyProps {
  open: boolean;
  onComplete: (data: any) => void;
}

export function OnboardingSurvey({ open, onComplete }: OnboardingSurveyProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: "",
    age: "",
    gender: "",
    familyHistory: [] as string[],
    grandparent1Age: "",
    grandparent2Age: "",
    grandparent3Age: "",
    grandparent4Age: "",
    motherAge: "",
    fatherAge: "",
    sleepHours: "",
    sleepQuality: "",
    exerciseFrequency: "",
    exerciseIntensity: "",
    dietType: "",
    meatConsumption: "",
    alcoholConsumption: "",
    smoker: "",
    stressLevel: "",
    socialActivities: "",
    workType: "",
  });

  const totalSteps = 5;
  const progress = (step / totalSteps) * 100;

  const handleNext = () => {
    if (step < totalSteps) {
      setStep(step + 1);
    } else {
      onComplete(formData);
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const handleFamilyHistoryChange = (condition: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      familyHistory: checked 
        ? [...prev.familyHistory, condition]
        : prev.familyHistory.filter(c => c !== condition)
    }));
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Basic Information</h3>
            <div className="space-y-4">
              <div>
                <Label htmlFor="name">Your Name</Label>
                <Input
                  id="name"
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({...prev, name: e.target.value}))}
                  placeholder="Enter your name"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="age">Age</Label>
                  <Input
                    id="age"
                    type="number"
                    value={formData.age}
                    onChange={(e) => setFormData(prev => ({...prev, age: e.target.value}))}
                    placeholder="48"
                  />
                </div>
                <div>
                  <Label htmlFor="gender">Gender</Label>
                  <Select value={formData.gender} onValueChange={(value) => setFormData(prev => ({...prev, gender: value}))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                      <SelectItem value="prefer-not-to-say">Prefer not to say</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Family Longevity History</h3>
            <p className="text-sm text-gray-600">This helps calculate your genetic longevity potential. Enter ages at death, or current age if still living:</p>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="grandparent1Age">Maternal Grandmother</Label>
                  <Input
                    id="grandparent1Age"
                    type="number"
                    value={formData.grandparent1Age}
                    onChange={(e) => setFormData(prev => ({...prev, grandparent1Age: e.target.value}))}
                    placeholder="Age at death or current age"
                  />
                </div>
                <div>
                  <Label htmlFor="grandparent2Age">Maternal Grandfather</Label>
                  <Input
                    id="grandparent2Age"
                    type="number"
                    value={formData.grandparent2Age}
                    onChange={(e) => setFormData(prev => ({...prev, grandparent2Age: e.target.value}))}
                    placeholder="Age at death or current age"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="grandparent3Age">Paternal Grandmother</Label>
                  <Input
                    id="grandparent3Age"
                    type="number"
                    value={formData.grandparent3Age}
                    onChange={(e) => setFormData(prev => ({...prev, grandparent3Age: e.target.value}))}
                    placeholder="Age at death or current age"
                  />
                </div>
                <div>
                  <Label htmlFor="grandparent4Age">Paternal Grandfather</Label>
                  <Input
                    id="grandparent4Age"
                    type="number"
                    value={formData.grandparent4Age}
                    onChange={(e) => setFormData(prev => ({...prev, grandparent4Age: e.target.value}))}
                    placeholder="Age at death or current age"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="motherAge">Mother</Label>
                  <Input
                    id="motherAge"
                    type="number"
                    value={formData.motherAge}
                    onChange={(e) => setFormData(prev => ({...prev, motherAge: e.target.value}))}
                    placeholder="Age at death or current age"
                  />
                </div>
                <div>
                  <Label htmlFor="fatherAge">Father</Label>
                  <Input
                    id="fatherAge"
                    type="number"
                    value={formData.fatherAge}
                    onChange={(e) => setFormData(prev => ({...prev, fatherAge: e.target.value}))}
                    placeholder="Age at death or current age"
                  />
                </div>
              </div>
            </div>
            
            <div className="space-y-3">
              <p className="text-sm text-gray-600">Select any conditions that run in your family:</p>
              {["Cardiovascular Disease", "Diabetes", "Cancer", "Dementia/Alzheimer's"].map((condition) => (
                <div key={condition} className="flex items-center space-x-2">
                  <Checkbox
                    id={condition}
                    checked={formData.familyHistory.includes(condition)}
                    onCheckedChange={(checked) => handleFamilyHistoryChange(condition, checked as boolean)}
                  />
                  <Label htmlFor={condition}>{condition}</Label>
                </div>
              ))}
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Sleep & Exercise</h3>
            <div className="space-y-3">
              <div>
                <Label htmlFor="sleepHours">Average sleep hours per night</Label>
                <Select value={formData.sleepHours} onValueChange={(value) => setFormData(prev => ({...prev, sleepHours: value}))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select hours" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="less-than-5">Less than 5 hours</SelectItem>
                    <SelectItem value="5-6">5-6 hours</SelectItem>
                    <SelectItem value="6-7">6-7 hours</SelectItem>
                    <SelectItem value="7-8">7-8 hours</SelectItem>
                    <SelectItem value="8-9">8-9 hours</SelectItem>
                    <SelectItem value="more-than-9">More than 9 hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="exerciseFrequency">Exercise frequency</Label>
                <Select value={formData.exerciseFrequency} onValueChange={(value) => setFormData(prev => ({...prev, exerciseFrequency: value}))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select frequency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="never">Never</SelectItem>
                    <SelectItem value="rarely">Rarely (1-2 times/month)</SelectItem>
                    <SelectItem value="sometimes">Sometimes (1-2 times/week)</SelectItem>
                    <SelectItem value="regularly">Regularly (3-4 times/week)</SelectItem>
                    <SelectItem value="daily">Daily</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Diet & Lifestyle</h3>
            <div className="space-y-3">
              <div>
                <Label htmlFor="meatConsumption">Meat consumption</Label>
                <Select value={formData.meatConsumption} onValueChange={(value) => setFormData(prev => ({...prev, meatConsumption: value}))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select frequency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="vegetarian">Vegetarian/Vegan</SelectItem>
                    <SelectItem value="rarely">Rarely (1-2 times/month)</SelectItem>
                    <SelectItem value="moderate">Moderate (2-3 times/week)</SelectItem>
                    <SelectItem value="regular">Regular (4-5 times/week)</SelectItem>
                    <SelectItem value="daily">Daily</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="alcoholConsumption">Alcohol consumption</Label>
                <Select value={formData.alcoholConsumption} onValueChange={(value) => setFormData(prev => ({...prev, alcoholConsumption: value}))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select frequency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="never">Never</SelectItem>
                    <SelectItem value="rarely">Rarely (special occasions)</SelectItem>
                    <SelectItem value="moderate">Moderate (1-2 drinks/week)</SelectItem>
                    <SelectItem value="regular">Regular (3-7 drinks/week)</SelectItem>
                    <SelectItem value="heavy">Heavy (8+ drinks/week)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="smoker">Smoking status</Label>
                <Select value={formData.smoker} onValueChange={(value) => setFormData(prev => ({...prev, smoker: value}))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="never">Never smoked</SelectItem>
                    <SelectItem value="former">Former smoker</SelectItem>
                    <SelectItem value="occasional">Occasional smoker</SelectItem>
                    <SelectItem value="regular">Regular smoker</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        );

      case 5:
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Social & Mental Wellbeing</h3>
            <div className="space-y-3">
              <div>
                <Label htmlFor="stressLevel">Stress level</Label>
                <Select value={formData.stressLevel} onValueChange={(value) => setFormData(prev => ({...prev, stressLevel: value}))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="very-low">Very low</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="moderate">Moderate</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="very-high">Very high</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="socialActivities">Social activities frequency</Label>
                <Select value={formData.socialActivities} onValueChange={(value) => setFormData(prev => ({...prev, socialActivities: value}))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select frequency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="rarely">Rarely</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="daily">Daily</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="workType">Work type</Label>
                <Select value={formData.workType} onValueChange={(value) => setFormData(prev => ({...prev, workType: value}))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sedentary">Sedentary (desk job)</SelectItem>
                    <SelectItem value="moderate">Moderate activity</SelectItem>
                    <SelectItem value="active">Active/Physical</SelectItem>
                    <SelectItem value="retired">Retired</SelectItem>
                    <SelectItem value="student">Student</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <Dialog open={open} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-md max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Welcome to LifeSpan+</DialogTitle>
          <p className="text-sm text-gray-600">Let's personalize your longevity journey</p>
        </DialogHeader>
        
        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-sm text-gray-600 mb-2">
              <span>Step {step} of {totalSteps}</span>
              <span>{Math.round(progress)}% complete</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          {renderStep()}

          <div className="flex justify-between pt-4">
            <Button
              variant="outline"
              onClick={handleBack}
              disabled={step === 1}
            >
              Back
            </Button>
            <Button onClick={handleNext}>
              {step === totalSteps ? "Complete Setup" : "Next"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}