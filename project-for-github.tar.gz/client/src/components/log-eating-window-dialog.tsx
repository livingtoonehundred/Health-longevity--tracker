import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Clock, Timer } from "lucide-react";

const formSchema = z.object({
  firstMealTime: z.string().min(1, "First meal time is required"),
  lastMealTime: z.string().min(1, "Last meal time is required"),
});

interface LogEatingWindowDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: z.infer<typeof formSchema>) => void;
  isLoading: boolean;
}

export function LogEatingWindowDialog({ open, onOpenChange, onSubmit, isLoading }: LogEatingWindowDialogProps) {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      firstMealTime: "",
      lastMealTime: "",
    },
  });

  const handleSubmit = (data: z.infer<typeof formSchema>) => {
    onSubmit(data);
    form.reset();
  };

  const calculateFastingWindow = () => {
    const firstMeal = form.watch("firstMealTime");
    const lastMeal = form.watch("lastMealTime");
    
    if (firstMeal && lastMeal) {
      const first = new Date(`1970-01-01T${firstMeal}:00`);
      const last = new Date(`1970-01-01T${lastMeal}:00`);
      
      let eatingHours = (last.getTime() - first.getTime()) / (1000 * 60 * 60);
      if (eatingHours < 0) eatingHours += 24;
      
      const fastingHours = 24 - eatingHours;
      return { eating: Math.round(eatingHours * 10) / 10, fasting: Math.round(fastingHours * 10) / 10 };
    }
    return null;
  };

  const windowStats = calculateFastingWindow();

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <Timer className="h-5 w-5 text-purple-600 dark:text-purple-400" />
            <DialogTitle>Log Eating Window</DialogTitle>
          </div>
          <DialogDescription>
            Track your first and last meal times to calculate your fasting window
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="firstMealTime"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    First Meal Time
                  </FormLabel>
                  <FormControl>
                    <Input
                      type="time"
                      placeholder="09:00"
                      {...field}
                      className="text-center"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="lastMealTime"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    Last Meal Time
                  </FormLabel>
                  <FormControl>
                    <Input
                      type="time"
                      placeholder="19:00"
                      {...field}
                      className="text-center"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {windowStats && (
              <div className="p-3 bg-purple-50 dark:bg-purple-950/30 rounded-lg border border-purple-200 dark:border-purple-800">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="text-center">
                    <p className="text-purple-700 dark:text-purple-300 font-medium">Eating Window</p>
                    <p className="text-lg font-bold text-purple-900 dark:text-purple-100">
                      {windowStats.eating}h
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="text-purple-700 dark:text-purple-300 font-medium">Fasting Period</p>
                    <p className="text-lg font-bold text-purple-900 dark:text-purple-100">
                      {windowStats.fasting}h
                    </p>
                  </div>
                </div>
                <div className="mt-2 text-center">
                  <span className={`text-xs font-medium ${
                    windowStats.fasting >= 16 ? "text-green-600 dark:text-green-400" :
                    windowStats.fasting >= 14 ? "text-blue-600 dark:text-blue-400" :
                    windowStats.fasting >= 12 ? "text-yellow-600 dark:text-yellow-400" :
                    "text-red-600 dark:text-red-400"
                  }`}>
                    {windowStats.fasting >= 16 ? "Peak Autophagy Benefits" :
                     windowStats.fasting >= 14 ? "Strong Longevity Benefits" :
                     windowStats.fasting >= 12 ? "Good Metabolic Benefits" :
                     "Limited Benefits"}
                  </span>
                </div>
              </div>
            )}

            <div className="flex gap-2 pt-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={isLoading}
                className="flex-1"
              >
                {isLoading ? "Calculating..." : "Log Window"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}