import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { LogFoodDialog } from "./log-food-dialog";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function FloatingActionButton() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const logQuickEntryMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/food", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/food"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsDialogOpen(false);
      
      toast({
        title: "Great choice!",
        description: "Your healthy habit has been logged successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to log entry. Please try again.",
        variant: "destructive",
      });
    },
  });

  return (
    <>
      <div className="fixed bottom-6 right-6">
        <Button
          className="w-14 h-14 bg-primary text-white rounded-full shadow-lg hover:bg-emerald-600 hover:scale-105 transition-all"
          onClick={() => setIsDialogOpen(true)}
        >
          <Plus className="w-6 h-6" />
        </Button>
      </div>

      <LogFoodDialog 
        open={isDialogOpen}
        onOpenChange={setIsDialogOpen}
        onSubmit={(data) => logQuickEntryMutation.mutate(data)}
        isLoading={logQuickEntryMutation.isPending}
      />
    </>
  );
}
