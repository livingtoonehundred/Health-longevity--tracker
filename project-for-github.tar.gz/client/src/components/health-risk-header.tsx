import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Heart, Brain, Droplets, Shield } from "lucide-react";

interface HealthRisks {
  cardiovascular: 'low' | 'medium' | 'high';
  diabetes: 'low' | 'medium' | 'high';
  cancer: 'low' | 'medium' | 'high';
  dementia: 'low' | 'medium' | 'high';
  details: {
    cardiovascular: string;
    diabetes: string;
    cancer: string;
    dementia: string;
  };
}

export function HealthRiskHeader() {
  const [selectedRisk, setSelectedRisk] = useState<string | null>(null);
  
  const { data: risks, isLoading } = useQuery<HealthRisks>({
    queryKey: ["/api/health-risks"],
  });

  if (isLoading || !risks) {
    return (
      <div className="bg-white border-b border-gray-200 px-4 py-3">
        <div className="max-w-7xl mx-auto">
          <div className="text-center text-gray-500">Loading health risk assessment...</div>
        </div>
      </div>
    );
  }

  const getRiskColor = (risk: 'low' | 'medium' | 'high') => {
    switch (risk) {
      case 'low': return 'bg-green-500';
      case 'medium': return 'bg-yellow-500';
      case 'high': return 'bg-red-500';
    }
  };

  const getRiskTextColor = (risk: 'low' | 'medium' | 'high') => {
    switch (risk) {
      case 'low': return 'text-green-700';
      case 'medium': return 'text-yellow-700';
      case 'high': return 'text-red-700';
    }
  };

  const riskItems = [
    {
      key: 'cardiovascular',
      label: 'Cardiovascular',
      icon: Heart,
      risk: risks.cardiovascular,
      detail: risks.details.cardiovascular
    },
    {
      key: 'diabetes',
      label: 'Diabetes',
      icon: Droplets,
      risk: risks.diabetes,
      detail: risks.details.diabetes
    },
    {
      key: 'cancer',
      label: 'Cancer',
      icon: Shield,
      risk: risks.cancer,
      detail: risks.details.cancer
    },
    {
      key: 'dementia',
      label: 'Dementia',
      icon: Brain,
      risk: risks.dementia,
      detail: risks.details.dementia
    }
  ];

  return (
    <>
      <div className="bg-white border-b border-gray-200 px-4 py-3">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <h2 className="text-sm font-medium text-gray-700">Health Risk Assessment</h2>
            <div className="grid grid-cols-2 sm:flex sm:items-center gap-2 sm:gap-4">
              {riskItems.map((item) => {
                const IconComponent = item.icon;
                return (
                  <button
                    key={item.key}
                    onClick={() => setSelectedRisk(item.key)}
                    className="flex items-center justify-between sm:justify-start space-x-2 hover:bg-gray-50 rounded-lg p-2 transition-colors min-w-0"
                  >
                    <div className="flex items-center space-x-2 min-w-0">
                      <IconComponent className="w-4 h-4 text-gray-600 flex-shrink-0" />
                      <span className="text-xs sm:text-sm font-medium text-gray-900 truncate">{item.label}</span>
                    </div>
                    <div className="flex items-center space-x-1 flex-shrink-0">
                      <div className={`w-3 h-3 rounded-full ${getRiskColor(item.risk)}`}></div>
                      <span className={`text-xs font-medium capitalize ${getRiskTextColor(item.risk)} hidden sm:inline`}>
                        {item.risk}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {selectedRisk && (
        <Dialog open={!!selectedRisk} onOpenChange={() => setSelectedRisk(null)}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-2">
                {(() => {
                  const item = riskItems.find(r => r.key === selectedRisk);
                  if (!item) return null;
                  const IconComponent = item.icon;
                  return (
                    <>
                      <IconComponent className="w-5 h-5" />
                      <span>{item.label} Risk Assessment</span>
                      <div className={`w-3 h-3 rounded-full ${getRiskColor(item.risk)} ml-2`}></div>
                    </>
                  );
                })()}
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Current Risk Level</h4>
                <div className="flex items-center space-x-2">
                  <div className={`w-4 h-4 rounded-full ${getRiskColor(
                    riskItems.find(r => r.key === selectedRisk)?.risk || 'medium'
                  )}`}></div>
                  <span className={`font-medium capitalize ${getRiskTextColor(
                    riskItems.find(r => r.key === selectedRisk)?.risk || 'medium'
                  )}`}>
                    {riskItems.find(r => r.key === selectedRisk)?.risk} Risk
                  </span>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Assessment & Recommendations</h4>
                <p className="text-sm text-gray-700 leading-relaxed">
                  {riskItems.find(r => r.key === selectedRisk)?.detail}
                </p>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}