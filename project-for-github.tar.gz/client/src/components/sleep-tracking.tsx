import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bed, Star } from "lucide-react";
import { LogSleepDialog } from "./log-sleep-dialog";
import { apiRequest } from "@/lib/queryClient";
import type { SleepEntry } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function SleepTracking() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: sleepEntries = [], isLoading } = useQuery<SleepEntry[]>({
    queryKey: ["/api/sleep"],
  });

  const logSleepMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/sleep", data);
      return response.json();
    },
    onSuccess: (newEntry: SleepEntry) => {
      queryClient.invalidateQueries({ queryKey: ["/api/sleep"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsDialogOpen(false);
      
      const hours = parseFloat(newEntry.lifeImpactHours);
      toast({
        title: "Sleep logged successfully!",
        description: `Your rest added ${hours > 0 ? '+' : ''}${hours.toFixed(1)} hours to your life!`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to log sleep entry. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return <div>Loading sleep data...</div>;
  }

  const latestSleep = sleepEntries[0];
  const lastNightHours = latestSleep ? parseFloat(latestSleep.duration) : 0;
  const quality = latestSleep?.quality || 0;

  return (
    <>
      <Card className="shadow-sm border border-gray-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-semibold text-gray-900">Sleep Quality</h3>
            <Bed className="text-purple-600 w-5 h-5" />
          </div>

          <div className="text-center mb-4">
            <p className="text-3xl font-bold text-gray-900">{lastNightHours.toFixed(1)}</p>
            <p className="text-sm text-gray-500">Hours last night</p>
            <div className="flex justify-center mt-2 space-x-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`w-4 h-4 ${
                    star <= quality ? "text-accent fill-current" : "text-gray-300"
                  }`}
                />
              ))}
            </div>
          </div>

          <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 mb-4">
            <p className="text-sm text-purple-800 font-medium">
              {quality >= 4 
                ? "Quality sleep boosts cellular repair and immune function, adding years to your life!"
                : "Improving sleep quality can significantly boost your body's recovery and longevity."
              }
            </p>
          </div>

          <Button 
            className="w-full bg-purple-600 text-white hover:bg-purple-700"
            onClick={() => setIsDialogOpen(true)}
          >
            Log Sleep Quality
          </Button>
        </CardContent>
      </Card>

      <LogSleepDialog 
        open={isDialogOpen}
        onOpenChange={setIsDialogOpen}
        onSubmit={(data) => logSleepMutation.mutate(data)}
        isLoading={logSleepMutation.isPending}
      />
    </>
  );
}
