import { Card, CardContent } from "@/components/ui/card";
import { Utensils, Footprints } from "lucide-react";

export function Recommendations() {
  const recommendations = [
    {
      type: "meal",
      title: "Meal Suggestion",
      description: "Try Mediterranean quinoa bowl with olive oil and nuts for longevity benefits",
      potential: "+2.2 hours",
      icon: Utensils,
      bgColor: "bg-green-50",
      borderColor: "border-green-200",
      iconBg: "bg-primary"
    },
    {
      type: "exercise",
      title: "Exercise Tip",
      description: "15-minute evening walk can improve sleep quality and metabolism",
      potential: "+1.5 hours",
      icon: Footprints,
      bgColor: "bg-blue-50",
      borderColor: "border-blue-200",
      iconBg: "bg-secondary"
    }
  ];

  return (
    <Card className="shadow-sm border border-gray-200">
      <CardContent className="p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-4">Today's Recommendations</h3>
        
        <div className="space-y-4">
          {recommendations.map((rec, index) => {
            const IconComponent = rec.icon;
            return (
              <div key={index} className={`border ${rec.borderColor} rounded-lg p-4 ${rec.bgColor}`}>
                <div className="flex items-start space-x-3">
                  <div className={`w-8 h-8 ${rec.iconBg} rounded-full flex items-center justify-center flex-shrink-0`}>
                    <IconComponent className="text-white w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">{rec.title}</h4>
                    <p className="text-sm text-gray-700 mt-1">{rec.description}</p>
                    <p className="text-xs text-success font-medium mt-2">Potential: {rec.potential}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
