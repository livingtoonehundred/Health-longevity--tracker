import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Activity } from "lucide-react";
import { LogExerciseDialog } from "./log-exercise-dialog";
import { apiRequest } from "@/lib/queryClient";
import type { ExerciseEntry } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

interface ExerciseTrackingProps {
  weeklyStats: {
    totalMinutes: number;
    totalCalories: number;
  };
}

export function ExerciseTracking({ weeklyStats }: ExerciseTrackingProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: recentExercises = [], isLoading } = useQuery<ExerciseEntry[]>({
    queryKey: ["/api/exercise"],
  });

  const logExerciseMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/exercise", data);
      return response.json();
    },
    onSuccess: (newEntry: ExerciseEntry) => {
      queryClient.invalidateQueries({ queryKey: ["/api/exercise"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsDialogOpen(false);
      
      const hours = parseFloat(newEntry.lifeImpactHours);
      toast({
        title: "Excellent workout!",
        description: `${newEntry.exerciseType} added ${hours > 0 ? '+' : ''}${hours.toFixed(1)} hours to your life!`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to log exercise entry. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return <div>Loading exercise entries...</div>;
  }

  const weeklyGoal = 300; // 5 hours per week
  const weeklyProgress = Math.min((weeklyStats.totalMinutes / weeklyGoal) * 100, 100);

  return (
    <>
      <Card className="shadow-sm border border-gray-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-semibold text-gray-900">Exercise Tracking</h3>
            <Button 
              className="bg-secondary text-white hover:bg-blue-600"
              onClick={() => setIsDialogOpen(true)}
            >
              Log Workout
            </Button>
          </div>

          {/* Exercise Progress */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <p className="text-2xl font-bold text-gray-900">{weeklyStats.totalMinutes}</p>
              <p className="text-sm text-gray-500">Minutes this week</p>
              <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                <div 
                  className="bg-secondary h-2 rounded-full transition-all duration-500" 
                  style={{ width: `${weeklyProgress}%` }}
                />
              </div>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <p className="text-2xl font-bold text-gray-900">{weeklyStats.totalCalories.toLocaleString()}</p>
              <p className="text-sm text-gray-500">Calories burned</p>
              <p className="text-xs text-success mt-1">
                +{(weeklyStats.totalMinutes * 0.1).toFixed(1)} hours added
              </p>
            </div>
          </div>

          {/* Recent Activities */}
          <div className="space-y-3">
            {recentExercises.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No exercise entries yet. Start your fitness journey!</p>
            ) : (
              recentExercises.slice(0, 3).map((exercise) => (
                <div key={exercise.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <Activity className="text-secondary w-4 h-4" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{exercise.exerciseType}</p>
                      <p className="text-sm text-gray-500">
                        {exercise.duration} minutes • {exercise.caloriesBurned} calories
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-success">
                      +{parseFloat(exercise.lifeImpactHours).toFixed(1)} hours
                    </p>
                    <p className="text-xs text-gray-500">Cardiovascular</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      <LogExerciseDialog 
        open={isDialogOpen}
        onOpenChange={setIsDialogOpen}
        onSubmit={(data) => logExerciseMutation.mutate(data)}
        isLoading={logExerciseMutation.isPending}
      />
    </>
  );
}
