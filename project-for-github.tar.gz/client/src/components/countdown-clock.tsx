import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { getQueryFn } from '@/lib/queryClient';
import { Clock, TrendingUp, TrendingDown } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

interface User {
  currentLifeExpectancy: string;
  age: number;
}

export function CountdownClock() {
  const [timeLeft, setTimeLeft] = useState({
    years: 0,
    months: 0,
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  const [totalSeconds, setTotalSeconds] = useState(0);
  const [previousExpectancy, setPreviousExpectancy] = useState<number | null>(null);
  const [changeIndicator, setChangeIndicator] = useState<'up' | 'down' | null>(null);

  const { data: user } = useQuery({
    queryKey: ["/api/user"],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });

  const userData = user as User;
  const currentExpectancy = userData?.currentLifeExpectancy ? parseFloat(userData.currentLifeExpectancy) : 0;

  useEffect(() => {
    // Track changes in life expectancy
    if (previousExpectancy !== null && currentExpectancy !== previousExpectancy) {
      setChangeIndicator(currentExpectancy > previousExpectancy ? 'up' : 'down');
      setTimeout(() => setChangeIndicator(null), 3000); // Clear indicator after 3 seconds
    }
    setPreviousExpectancy(currentExpectancy);
  }, [currentExpectancy, previousExpectancy]);

  // Calculate initial time left when data loads
  useEffect(() => {
    if (!userData?.age) return;
    
    const currentAge = userData.age;
    const yearsLeft = Math.max(0, currentExpectancy - currentAge);
    const initialSeconds = Math.floor(yearsLeft * 365.25 * 24 * 60 * 60);
    
    // If this is an update (not initial load), add the difference to show immediate impact
    if (totalSeconds > 0) {
      const difference = initialSeconds - totalSeconds;
      setTotalSeconds(prev => prev + difference);
    } else {
      setTotalSeconds(initialSeconds);
    }
  }, [currentExpectancy, userData?.age]);

  // Main countdown timer that decrements every second
  useEffect(() => {
    if (totalSeconds <= 0) return;

    const timer = setInterval(() => {
      setTotalSeconds(prev => {
        const newTotal = Math.max(0, prev - 1);
        
        // Convert seconds to time components
        const secondsPerYear = 365.25 * 24 * 60 * 60;
        const secondsPerMonth = 30.44 * 24 * 60 * 60;
        const secondsPerDay = 24 * 60 * 60;
        const secondsPerHour = 60 * 60;
        const secondsPerMinute = 60;
        
        const years = Math.floor(newTotal / secondsPerYear);
        const remainingAfterYears = newTotal % secondsPerYear;
        
        const months = Math.floor(remainingAfterYears / secondsPerMonth);
        const remainingAfterMonths = remainingAfterYears % secondsPerMonth;
        
        const days = Math.floor(remainingAfterMonths / secondsPerDay);
        const remainingAfterDays = remainingAfterMonths % secondsPerDay;
        
        const hours = Math.floor(remainingAfterDays / secondsPerHour);
        const remainingAfterHours = remainingAfterDays % secondsPerHour;
        
        const minutes = Math.floor(remainingAfterHours / secondsPerMinute);
        const seconds = Math.floor(remainingAfterHours % secondsPerMinute);

        setTimeLeft({ years, months, days, hours, minutes, seconds });
        
        return newTotal;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [totalSeconds]);

  const formatNumber = (num: number) => num.toString().padStart(2, '0');

  return (
    <Card className="relative overflow-hidden bg-gradient-to-br from-slate-900 to-slate-800 text-white">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <Clock className="w-5 h-5 text-blue-400" />
            <h3 className="text-lg font-semibold">Life Countdown</h3>
          </div>
          {changeIndicator && (
            <div className={`flex items-center space-x-1 animate-pulse ${
              changeIndicator === 'up' ? 'text-green-400' : 'text-red-400'
            }`}>
              {changeIndicator === 'up' ? (
                <TrendingUp className="w-4 h-4" />
              ) : (
                <TrendingDown className="w-4 h-4" />
              )}
              <span className="text-sm font-medium">
                {changeIndicator === 'up' ? 'Time Added!' : 'Time Lost'}
              </span>
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4">
          <div className="text-center">
            <div className="text-2xl md:text-3xl font-bold text-blue-400">
              {formatNumber(timeLeft.years)}
            </div>
            <div className="text-xs text-gray-300">Years</div>
          </div>
          <div className="text-center">
            <div className="text-2xl md:text-3xl font-bold text-green-400">
              {formatNumber(timeLeft.months)}
            </div>
            <div className="text-xs text-gray-300">Months</div>
          </div>
          <div className="text-center">
            <div className="text-2xl md:text-3xl font-bold text-yellow-400">
              {formatNumber(timeLeft.days)}
            </div>
            <div className="text-xs text-gray-300">Days</div>
          </div>
          <div className="text-center">
            <div className="text-xl md:text-2xl font-bold text-purple-400">
              {formatNumber(timeLeft.hours)}
            </div>
            <div className="text-xs text-gray-300">Hours</div>
          </div>
          <div className="text-center">
            <div className="text-xl md:text-2xl font-bold text-pink-400">
              {formatNumber(timeLeft.minutes)}
            </div>
            <div className="text-xs text-gray-300">Minutes</div>
          </div>
          <div className="text-center">
            <div className="text-xl md:text-2xl font-bold text-red-400">
              {formatNumber(timeLeft.seconds)}
            </div>
            <div className="text-xs text-gray-300">Seconds</div>
          </div>
        </div>

        <div className="text-center text-sm text-gray-400">
          Expected lifespan: {currentExpectancy.toFixed(1)} years
        </div>

        <div className="mt-4 text-center">
          <p className="text-xs text-gray-400">
            Every healthy choice extends your time ⏰
          </p>
        </div>
      </CardContent>
    </Card>
  );
}