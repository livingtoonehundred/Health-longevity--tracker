import React, { useState, useRef } from 'react';
import { Camera, Upload, X, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface PhotoFoodAnalyzerProps {
  onFoodIdentified: (foodName: string, confidence: number) => void;
  isLoading?: boolean;
}

export function PhotoFoodAnalyzer({ onFoodIdentified, isLoading = false }: PhotoFoodAnalyzerProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<{
    foodName: string;
    confidence: number;
    alternatives?: string[];
  } | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const handleImageSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    console.log('File input triggered', event.target.files);
    const file = event.target.files?.[0];
    if (file) {
      console.log('File selected:', file.name, file.type);
      const reader = new FileReader();
      reader.onload = (e) => {
        const imageData = e.target?.result as string;
        setSelectedImage(imageData);
        analyzeImage(imageData);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCameraClick = (e: React.MouseEvent) => {
    e.preventDefault();
    console.log('Camera button clicked');
    if (cameraInputRef.current) {
      console.log('Triggering camera input');
      // Force focus and trigger click
      cameraInputRef.current.focus();
      cameraInputRef.current.click();
    }
  };

  const handleGalleryClick = (e: React.MouseEvent) => {
    e.preventDefault();
    console.log('Gallery button clicked');
    if (fileInputRef.current) {
      console.log('Triggering file input');
      // Force focus and trigger click
      fileInputRef.current.focus();
      fileInputRef.current.click();
    }
  };

  const analyzeImage = async (imageData: string) => {
    setAnalyzing(true);
    setAnalysisResult(null);

    try {
      // Convert base64 to just the data part
      const base64Data = imageData.split(',')[1];
      
      const response = await fetch('/api/analyze-food-photo', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          image: base64Data,
          format: 'jpeg'
        }),
      });

      if (response.ok) {
        const result = await response.json();
        setAnalysisResult(result);
      } else {
        throw new Error('Failed to analyze image');
      }
    } catch (error) {
      console.error('Image analysis error:', error);
      // Fallback to manual entry
      setAnalysisResult({
        foodName: 'Unable to identify food',
        confidence: 0,
        alternatives: ['Please enter food name manually']
      });
    } finally {
      setAnalyzing(false);
    }
  };

  const handleConfirmFood = () => {
    if (analysisResult) {
      onFoodIdentified(analysisResult.foodName, analysisResult.confidence);
      resetAnalyzer();
    }
  };

  const resetAnalyzer = () => {
    setSelectedImage(null);
    setAnalysisResult(null);
    setAnalyzing(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (cameraInputRef.current) cameraInputRef.current.value = '';
  };

  return (
    <Card className="border-blue-200 bg-blue-50">
      <CardContent className="p-6">
        {!selectedImage ? (
          <div className="space-y-3">
            <div className="text-center p-4 border-2 border-dashed border-blue-300 rounded-lg bg-blue-25">
              <Camera className="w-12 h-12 text-blue-400 mx-auto mb-3" />
              <h4 className="font-medium text-blue-900 mb-2">Ready to Analyze Your Food</h4>
              <p className="text-sm text-blue-700 mb-4">
                Upload a photo of your meal and our AI will identify the food and calculate its nutrition score automatically.
              </p>
              
              <label htmlFor="food-photo-input" className="inline-block">
                <div className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg cursor-pointer transition-colors font-medium">
                  Select Photo or Take Picture
                </div>
              </label>
              
              <input
                id="food-photo-input"
                type="file"
                accept="image/*"
                capture="environment"
                className="hidden"
                onChange={handleImageSelect}
              />
            </div>
            
            <div className="text-xs text-center text-blue-600 space-y-1">
              <p>• On mobile: Choose "Camera" to take a new photo</p>
              <p>• Or select "Photo Library" to upload an existing image</p>
              <p>• AI will identify food and suggest nutrition scoring</p>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="relative">
              <img 
                src={selectedImage} 
                alt="Food to analyze" 
                className="w-full h-48 object-cover rounded-lg"
              />
              <Button
                size="sm"
                variant="outline"
                className="absolute top-2 right-2 bg-white"
                onClick={resetAnalyzer}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>

            {analyzing && (
              <div className="text-center py-4">
                <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2 text-blue-600" />
                <p className="text-sm text-blue-700">Analyzing food image...</p>
              </div>
            )}

            {analysisResult && (
              <div className="space-y-3">
                <div className="bg-white rounded-lg p-4 border border-blue-200">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold text-gray-900">Identified Food</h4>
                    <Badge 
                      variant={analysisResult.confidence > 0.7 ? "default" : "secondary"}
                      className={analysisResult.confidence > 0.7 ? "bg-green-100 text-green-800" : ""}
                    >
                      {Math.round(analysisResult.confidence * 100)}% confident
                    </Badge>
                  </div>
                  
                  <p className="text-lg font-medium text-gray-900 mb-2">
                    {analysisResult.foodName}
                  </p>

                  {analysisResult.alternatives && analysisResult.alternatives.length > 0 && (
                    <div className="mb-3">
                      <p className="text-sm text-gray-600 mb-1">Alternative suggestions:</p>
                      <div className="flex flex-wrap gap-2">
                        {analysisResult.alternatives.map((alt, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {alt}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="flex space-x-2">
                    <Button 
                      onClick={handleConfirmFood}
                      className="flex-1 bg-blue-600 hover:bg-blue-700"
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Processing...
                        </>
                      ) : (
                        'Use This Food'
                      )}
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={resetAnalyzer}
                      disabled={isLoading}
                    >
                      Try Again
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        <div className="mt-4 text-center">
          <p className="text-xs text-blue-600">
            AI analyzes your food photo for automatic nutrition scoring
          </p>
        </div>
      </CardContent>
    </Card>
  );
}