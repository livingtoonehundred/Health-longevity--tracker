import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Trophy, Medal } from "lucide-react";
import type { Achievement } from "@shared/schema";

export function Achievements() {
  const { data: achievements = [], isLoading } = useQuery<Achievement[]>({
    queryKey: ["/api/achievements"],
  });

  if (isLoading) {
    return <div>Loading achievements...</div>;
  }

  // Default achievements if none exist
  const defaultAchievements = [
    {
      id: 1,
      title: "7-Day Streak!",
      description: "Consistent healthy eating",
      icon: "trophy",
      achievedAt: new Date()
    },
    {
      id: 2,
      title: "Exercise Champion",
      description: "300+ minutes this week",
      icon: "medal",
      achievedAt: new Date()
    }
  ];

  const displayAchievements = achievements.length > 0 ? achievements : defaultAchievements;

  return (
    <Card className="shadow-sm border border-gray-200">
      <CardContent className="p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-4">Recent Achievements</h3>
        
        <div className="space-y-3">
          {displayAchievements.slice(0, 2).map((achievement, index) => (
            <div key={achievement.id || index} className={`flex items-center space-x-3 p-3 rounded-lg ${
              index === 0 ? 'bg-gradient-to-r from-accent/10 to-orange-100' : 'bg-gradient-to-r from-primary/10 to-green-100'
            }`}>
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                index === 0 ? 'bg-accent' : 'bg-primary'
              }`}>
                {index === 0 ? (
                  <Trophy className="text-white w-5 h-5" />
                ) : (
                  <Medal className="text-white w-5 h-5" />
                )}
              </div>
              <div>
                <p className="font-medium text-gray-900">{achievement.title}</p>
                <p className="text-sm text-gray-600">{achievement.description}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
