import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { getQueryFn } from '@/lib/queryClient';
import { Lightbulb, Target, Zap } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface SuggestionProps {
  category: 'food' | 'exercise' | 'sleep';
  currentScore?: number;
  recentEntries?: any[];
}

export function LongevitySuggestions({ category, currentScore = 0, recentEntries = [] }: SuggestionProps) {
  const { data: user } = useQuery({
    queryKey: ["/api/user"],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });

  const generateSuggestions = () => {
    const userData = user as any;
    
    switch (category) {
      case 'food':
        return getFoodSuggestions(currentScore, recentEntries, userData);
      case 'exercise':
        return getExerciseSuggestions(recentEntries, userData);
      case 'sleep':
        return getSleepSuggestions(recentEntries);
      default:
        return [];
    }
  };

  const getFoodSuggestions = (score: number, entries: any[], userData: any) => {
    const suggestions = [];
    
    if (score < 50) {
      suggestions.push({
        title: "Add Leafy Greens",
        description: "Include spinach or kale in your next meal for +2.5 hours",
        impact: "+2.5 hours",
        difficulty: "Easy",
        category: "Vegetables"
      });
    }
    
    if (score < 70) {
      suggestions.push({
        title: "Choose Wild Salmon",
        description: "Omega-3 rich fish can add significant longevity benefits",
        impact: "+1.8 hours",
        difficulty: "Medium",
        category: "Protein"
      });
    }

    suggestions.push({
      title: "Add Blueberries",
      description: "Antioxidant powerhouse for cellular protection",
      impact: "+1.2 hours",
      difficulty: "Easy",
      category: "Fruits"
    });

    if (entries.length > 0) {
      const lastFood = entries[0]?.foodName?.toLowerCase() || '';
      if (lastFood.includes('processed') || lastFood.includes('fast')) {
        suggestions.push({
          title: "Balance with Whole Foods",
          description: "Counter processed foods with nutrient-dense options",
          impact: "+0.8 hours",
          difficulty: "Easy",
          category: "Balance"
        });
      }
    }

    return suggestions.slice(0, 3);
  };

  const getExerciseSuggestions = (entries: any[], userData: any) => {
    const suggestions = [];
    const todayMinutes = entries.reduce((sum, entry) => sum + (entry.duration || 0), 0);
    
    if (todayMinutes < 30) {
      suggestions.push({
        title: "20-Minute Walk",
        description: "Easy cardiovascular boost to reach daily minimum",
        impact: "+1.5 hours",
        difficulty: "Easy",
        category: "Cardio"
      });
    }

    if (todayMinutes < 60) {
      suggestions.push({
        title: "Strength Training",
        description: "15 minutes of bodyweight exercises",
        impact: "+2.2 hours",
        difficulty: "Medium",
        category: "Strength"
      });
    }

    suggestions.push({
      title: "High-Intensity Interval",
      description: "10-minute HIIT session for maximum longevity impact",
      impact: "+3.1 hours",
      difficulty: "Hard",
      category: "HIIT"
    });

    return suggestions.slice(0, 3);
  };

  const getSleepSuggestions = (entries: any[]) => {
    const suggestions = [];
    const lastSleep = entries[0];
    
    if (!lastSleep || lastSleep.duration < 7) {
      suggestions.push({
        title: "Aim for 7-8 Hours",
        description: "Optimal sleep duration for cellular repair",
        impact: "+2.8 hours",
        difficulty: "Medium",
        category: "Duration"
      });
    }

    if (!lastSleep || lastSleep.quality < 4) {
      suggestions.push({
        title: "Sleep Hygiene",
        description: "Dark room, cool temperature, no screens 1hr before bed",
        impact: "+1.9 hours",
        difficulty: "Easy",
        category: "Quality"
      });
    }

    suggestions.push({
      title: "Consistent Schedule",
      description: "Same bedtime and wake time daily",
      impact: "+1.4 hours",
      difficulty: "Medium",
      category: "Routine"
    });

    return suggestions.slice(0, 3);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'bg-green-100 text-green-800';
      case 'Medium': return 'bg-yellow-100 text-yellow-800';
      case 'Hard': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const suggestions = generateSuggestions();

  if (suggestions.length === 0) {
    return null;
  }

  return (
    <Card className="border-amber-200 bg-amber-50">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center space-x-2 text-amber-800">
          <Target className="w-5 h-5" />
          <span>Maximize Your Longevity</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {suggestions.map((suggestion, index) => (
          <div key={index} className="bg-white rounded-lg p-4 border border-amber-200">
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1">
                <h4 className="font-semibold text-gray-900 mb-1">{suggestion.title}</h4>
                <p className="text-sm text-gray-600 mb-2">{suggestion.description}</p>
                <div className="flex items-center space-x-2">
                  <Badge variant="outline" className="text-green-700 border-green-200">
                    <Zap className="w-3 h-3 mr-1" />
                    {suggestion.impact}
                  </Badge>
                  <Badge className={getDifficultyColor(suggestion.difficulty)}>
                    {suggestion.difficulty}
                  </Badge>
                  <Badge variant="secondary">
                    {suggestion.category}
                  </Badge>
                </div>
              </div>
            </div>
            <Button size="sm" className="w-full bg-amber-600 hover:bg-amber-700 text-white">
              <Lightbulb className="w-4 h-4 mr-2" />
              Apply This Suggestion
            </Button>
          </div>
        ))}
        
        <div className="text-center pt-2">
          <p className="text-xs text-amber-700">
            Suggestions adapt based on your progress and preferences
          </p>
        </div>
      </CardContent>
    </Card>
  );
}