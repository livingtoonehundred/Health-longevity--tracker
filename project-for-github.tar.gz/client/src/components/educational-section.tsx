import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Dna, Leaf, Brain } from "lucide-react";
import type { EducationalContent } from "@shared/schema";

export function EducationalSection() {
  const { data: educationalContent = [], isLoading } = useQuery<EducationalContent[]>({
    queryKey: ["/api/education"],
  });

  if (isLoading) {
    return <div>Loading educational content...</div>;
  }

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "dna":
        return Dna;
      case "leaf":
        return Leaf;
      case "brain":
        return Brain;
      default:
        return Dna;
    }
  };

  const getIconBgColor = (category: string) => {
    switch (category) {
      case "exercise":
        return "bg-blue-100";
      case "nutrition":
        return "bg-green-100";
      case "sleep":
        return "bg-purple-100";
      default:
        return "bg-blue-100";
    }
  };

  const getIconColor = (category: string) => {
    switch (category) {
      case "exercise":
        return "text-secondary";
      case "nutrition":
        return "text-primary";
      case "sleep":
        return "text-purple-600";
      default:
        return "text-secondary";
    }
  };

  return (
    <section className="mt-8 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-8 border border-blue-200">
      <div className="text-center mb-6">
        <h3 className="text-2xl font-bold text-gray-900 mb-2">Learn Something New Today</h3>
        <p className="text-gray-600">Understanding the science behind longevity helps you make better choices</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {educationalContent.map((content) => {
          const IconComponent = getIcon(content.icon);
          return (
            <Card 
              key={content.id} 
              className="shadow-sm border border-gray-200 hover:shadow-md transition-shadow cursor-pointer"
            >
              <CardContent className="p-6">
                <div className={`w-12 h-12 ${getIconBgColor(content.category)} rounded-full flex items-center justify-center mb-4`}>
                  <IconComponent className={`${getIconColor(content.category)} w-6 h-6`} />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">{content.title}</h4>
                <p className="text-sm text-gray-600 mb-3">{content.description}</p>
                <span className="text-xs font-medium text-secondary">{content.readTime} min read</span>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </section>
  );
}
