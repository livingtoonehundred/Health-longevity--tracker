import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Clock, Timer, Plus } from "lucide-react";
import { LogEatingWindowDialog } from "./log-eating-window-dialog";
import { apiRequest } from "@/lib/queryClient";
import { cn } from "@/lib/utils";

interface EatingWindow {
  id: number;
  userId: number;
  firstMealTime: string;
  lastMealTime: string;
  fastingHours: number;
  eatingWindowHours: number;
  lifeImpactHours: string;
  explanation: string;
  loggedAt: string;
}

export function EatingWindowTracking() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const queryClient = useQueryClient();

  const { data: eatingWindows = [], isLoading } = useQuery<EatingWindow[]>({
    queryKey: ["/api/eating-windows"],
  });

  const { data: todaysWindow } = useQuery<EatingWindow | null>({
    queryKey: ["/api/eating-windows/today"],
  });

  const createEatingWindowMutation = useMutation({
    mutationFn: async (data: {
      firstMealTime: string;
      lastMealTime: string;
      fastingHours: number;
      eatingWindowHours: number;
    }) => {
      return fetch("/api/eating-windows", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      }).then(res => res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/eating-windows"] });
      queryClient.invalidateQueries({ queryKey: ["/api/eating-windows/today"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setDialogOpen(false);
    },
  });

  const handleSubmit = (data: any) => {
    const firstMeal = new Date(`1970-01-01T${data.firstMealTime}:00`);
    const lastMeal = new Date(`1970-01-01T${data.lastMealTime}:00`);
    
    let eatingWindowHours = (lastMeal.getTime() - firstMeal.getTime()) / (1000 * 60 * 60);
    if (eatingWindowHours < 0) eatingWindowHours += 24; // Handle overnight eating
    
    const fastingHours = 24 - eatingWindowHours;

    createEatingWindowMutation.mutate({
      firstMealTime: data.firstMealTime,
      lastMealTime: data.lastMealTime,
      fastingHours,
      eatingWindowHours,
    });
  };

  const formatTime = (timeStr: string) => {
    const [hours, minutes] = timeStr.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  const getFastingBenefitColor = (hours: number) => {
    if (hours >= 16) return "text-green-600 dark:text-green-400";
    if (hours >= 14) return "text-blue-600 dark:text-blue-400";
    if (hours >= 12) return "text-yellow-600 dark:text-yellow-400";
    return "text-red-600 dark:text-red-400";
  };

  const getFastingBenefitText = (hours: number) => {
    if (hours >= 16) return "Peak Autophagy";
    if (hours >= 14) return "Strong Benefits";
    if (hours >= 12) return "Good Benefits";
    return "Limited Benefits";
  };

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Timer className="h-5 w-5 text-purple-600 dark:text-purple-400" />
            <CardTitle className="text-lg">Time-Restricted Eating</CardTitle>
          </div>
          <Button 
            onClick={() => setDialogOpen(true)}
            size="sm"
            className="h-8 w-8 p-0"
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>
        <CardDescription>
          Track your fasting windows for longevity benefits
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Today's Window Status */}
        {todaysWindow ? (
          <div className="p-4 bg-purple-50 dark:bg-purple-950/30 rounded-lg border border-purple-200 dark:border-purple-800">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-medium text-purple-900 dark:text-purple-100">Today's Fast</h4>
              <span className={cn(
                "text-sm font-medium",
                getFastingBenefitColor(todaysWindow.fastingHours)
              )}>
                {getFastingBenefitText(todaysWindow.fastingHours)}
              </span>
            </div>
            
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-purple-700 dark:text-purple-300">Eating Window</p>
                <p className="font-medium">
                  {formatTime(todaysWindow.firstMealTime)} - {formatTime(todaysWindow.lastMealTime)}
                </p>
                <p className="text-xs text-purple-600 dark:text-purple-400">
                  {todaysWindow.eatingWindowHours}h window
                </p>
              </div>
              <div>
                <p className="text-purple-700 dark:text-purple-300">Fasting</p>
                <p className="font-medium">{todaysWindow.fastingHours}h</p>
                <p className={cn(
                  "text-xs font-medium",
                  parseFloat(todaysWindow.lifeImpactHours) > 0 ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"
                )}>
                  {parseFloat(todaysWindow.lifeImpactHours) > 0 ? "+" : ""}{todaysWindow.lifeImpactHours}h life
                </p>
              </div>
            </div>
            
            <p className="text-xs text-purple-600 dark:text-purple-400 mt-2">
              {todaysWindow.explanation}
            </p>
          </div>
        ) : (
          <div className="p-4 bg-gray-50 dark:bg-gray-900/50 rounded-lg border border-gray-200 dark:border-gray-800 text-center">
            <Clock className="h-8 w-8 text-gray-400 mx-auto mb-2" />
            <p className="text-sm text-gray-600 dark:text-gray-400">
              No eating window logged today
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
              Track your first and last meal times
            </p>
          </div>
        )}

        {/* Recent Windows */}
        {eatingWindows.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">Recent Fasting Windows</h4>
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {eatingWindows.slice(0, 5).map((window: EatingWindow) => (
                <div 
                  key={window.id}
                  className="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-900/50 rounded text-sm"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-gray-600 dark:text-gray-400">
                      {new Date(window.loggedAt).toLocaleDateString()}
                    </span>
                    <span className="text-gray-500 dark:text-gray-500">•</span>
                    <span>{window.fastingHours}h fast</span>
                  </div>
                  <span className={cn(
                    "text-xs font-medium",
                    parseFloat(window.lifeImpactHours) > 0 ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"
                  )}>
                    {parseFloat(window.lifeImpactHours) > 0 ? "+" : ""}{window.lifeImpactHours}h
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>

      <LogEatingWindowDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        onSubmit={handleSubmit}
        isLoading={createEatingWindowMutation.isPending}
      />
    </Card>
  );
}