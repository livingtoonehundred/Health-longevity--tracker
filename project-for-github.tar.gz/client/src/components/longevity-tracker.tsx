import { useQuery } from "@tanstack/react-query";
import type { User } from "@shared/schema";

export function LongevityTracker() {
  const { data: user } = useQuery<User>({
    queryKey: ["/api/user"],
  });

  if (!user) return null;

  const lifeExtensionHours = parseFloat(user.totalLifeExtension);
  const lifeExtensionYears = lifeExtensionHours / 8760; // Convert hours to years
  const currentAge = parseFloat(user.currentLifeExpectancy);
  const baseAge = parseFloat(user.baseLifeExpectancy);
  const progressPercentage = Math.min((lifeExtensionYears / 5) * 100, 100); // Assuming 5 years is max goal
  const addedDays = Math.round(lifeExtensionHours / 24); // Convert hours to days

  // Calculate circle progress (377 is approximately the circumference for r=60)
  const circleProgress = 377 - (progressPercentage / 100) * 377;

  return (
    <div className="bg-gradient-to-r from-primary to-emerald-600 rounded-2xl p-4 sm:p-6 lg:p-8 text-white">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-8 items-center">
        <div>
          <h2 className="text-2xl sm:text-3xl font-bold mb-2">Your Longevity Journey</h2>
          <p className="text-emerald-100 mb-4 lg:mb-6 text-sm sm:text-base">Every positive choice adds precious time to your life. Keep building those healthy habits!</p>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 lg:p-6">
            <div className="flex items-center justify-between mb-3 lg:mb-4">
              <span className="text-xs sm:text-sm text-emerald-100">Life Extension</span>
              <span className="text-xl sm:text-2xl font-bold">+{lifeExtensionYears.toFixed(2)} years</span>
            </div>
            
            <div className="w-full bg-white/20 rounded-full h-2 lg:h-3 mb-2">
              <div 
                className="bg-accent h-2 lg:h-3 rounded-full transition-all duration-500" 
                style={{ width: `${progressPercentage}%` }}
              />
            </div>
            <p className="text-xs text-emerald-100">{Math.round(progressPercentage)}% towards your next milestone!</p>
          </div>
        </div>
        
        <div className="flex justify-center mt-4 lg:mt-0">
          <div className="relative w-32 h-32 sm:w-40 sm:h-40 lg:w-48 lg:h-48">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 144 144">
              <circle 
                cx="72" 
                cy="72" 
                r="60" 
                stroke="rgba(255,255,255,0.2)" 
                strokeWidth="6" 
                fill="none"
              />
              <circle 
                cx="72" 
                cy="72" 
                r="60" 
                stroke="#F59E0B" 
                strokeWidth="6" 
                fill="none" 
                strokeDasharray="377" 
                strokeDashoffset={circleProgress}
                strokeLinecap="round"
                className="transition-all duration-500"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="text-2xl sm:text-3xl lg:text-4xl font-bold">{Math.round(currentAge)}</span>
              <span className="text-xs sm:text-sm text-emerald-100">Years Expected</span>
              <span className="text-xs text-emerald-200 mt-1">+{addedDays} days added</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
