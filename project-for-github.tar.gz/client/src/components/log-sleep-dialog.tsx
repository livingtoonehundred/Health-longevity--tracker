import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface LogSleepDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: any) => void;
  isLoading: boolean;
}

export function LogSleepDialog({ open, onOpenChange, onSubmit, isLoading }: LogSleepDialogProps) {
  const [duration, setDuration] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!duration) {
      return;
    }

    onSubmit({
      userId: 1, // Default user for demo
      duration: parseFloat(duration),
      quality: 3, // Default quality score
    });

    // Reset form
    setDuration("");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Log Sleep Quality</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="duration">Sleep Duration (hours)</Label>
            <Input
              id="duration"
              type="number"
              step="0.5"
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
              placeholder="8.0"
              min="1"
              max="12"
              required
            />
            <p className="text-xs text-gray-500 mt-1">
              How many hours did you sleep?
            </p>
          </div>

          <div className="flex gap-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="flex-1 bg-purple-600 hover:bg-purple-700"
              disabled={isLoading}
            >
              {isLoading ? "Logging..." : "Log Sleep"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
