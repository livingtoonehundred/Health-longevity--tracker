import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Leaf, Droplets, Heart, Brain, Shield } from "lucide-react";

interface FoodHack {
  id: string;
  name: string;
  category: string;
  benefits: string[];
  mealSuggestion: string;
  explanation: string;
  activeIngredients: string[];
  icon: any;
  color: string;
}

export function LongevityToolkit() {
  const foodHacks: FoodHack[] = [
    {
      id: "olive-oil",
      name: "Extra Virgin Olive Oil",
      category: "Healthy Fats",
      benefits: ["Anti-inflammatory", "Heart Health", "Brain Protection"],
      mealSuggestion: "Drizzle 2 tbsp over mixed greens with lemon juice, or use for cooking vegetables",
      explanation: "Rich in oleic acid and polyphenols that reduce inflammation and protect against cardiovascular disease.",
      activeIngredients: ["Oleic acid", "Polyphenols", "Vitamin E"],
      icon: Droplets,
      color: "bg-green-100 text-green-800"
    },
    {
      id: "turmeric",
      name: "Turmeric",
      category: "Spices",
      benefits: ["Anti-inflammatory", "Antioxidant", "Joint Health"],
      mealSuggestion: "Golden milk latte or add 1 tsp to curry, rice dishes, or smoothies",
      explanation: "Curcumin reduces chronic inflammation and may protect against age-related diseases.",
      activeIngredients: ["Curcumin", "Turmerones"],
      icon: Shield,
      color: "bg-yellow-100 text-yellow-800"
    },
    {
      id: "tree-nuts",
      name: "Tree Nuts",
      category: "Protein & Fats",
      benefits: ["Heart Health", "Brain Function", "Longevity"],
      mealSuggestion: "1 oz mixed almonds, walnuts, and pistachios as snack or in yogurt",
      explanation: "Provide healthy fats, protein, and magnesium that support cardiovascular and cognitive health.",
      activeIngredients: ["Omega-3 fatty acids", "Magnesium", "Vitamin E"],
      icon: Heart,
      color: "bg-amber-100 text-amber-800"
    },
    {
      id: "brassicas",
      name: "Brassica Vegetables",
      category: "Vegetables",
      benefits: ["Cancer Prevention", "Detoxification", "Immune Support"],
      mealSuggestion: "Roasted broccoli, cauliflower, and Brussels sprouts with garlic and olive oil",
      explanation: "Sulforaphane and other compounds support the body's natural detoxification processes.",
      activeIngredients: ["Sulforaphane", "Indole-3-carbinol", "Glucosinolates"],
      icon: Leaf,
      color: "bg-green-100 text-green-800"
    },
    {
      id: "beans-lentils",
      name: "Beans & Lentils",
      category: "Legumes",
      benefits: ["Heart Health", "Blood Sugar Control", "Fiber"],
      mealSuggestion: "Mediterranean lentil soup or black bean and quinoa bowl with vegetables",
      explanation: "High fiber content supports gut health and helps regulate blood sugar and cholesterol.",
      activeIngredients: ["Soluble fiber", "Plant protein", "Folate"],
      icon: Heart,
      color: "bg-red-100 text-red-800"
    },
    {
      id: "polyphenols",
      name: "Polyphenol-Rich Foods",
      category: "Antioxidants",
      benefits: ["Antioxidant", "Anti-aging", "Cellular Protection"],
      mealSuggestion: "Dark berries, green tea, and 85% dark chocolate (1 oz)",
      explanation: "Powerful antioxidants that protect cells from oxidative damage and support healthy aging.",
      activeIngredients: ["Anthocyanins", "Catechins", "Resveratrol"],
      icon: Shield,
      color: "bg-purple-100 text-purple-800"
    },
    {
      id: "flavonoids",
      name: "Flavonoid Foods",
      category: "Plant Compounds",
      benefits: ["Brain Health", "Heart Protection", "Anti-inflammatory"],
      mealSuggestion: "Colorful fruit salad with berries, citrus, and apples",
      explanation: "Support cognitive function and cardiovascular health through multiple pathways.",
      activeIngredients: ["Quercetin", "Rutin", "Hesperidin"],
      icon: Brain,
      color: "bg-blue-100 text-blue-800"
    },
    {
      id: "probiotics",
      name: "Probiotic Foods",
      category: "Gut Health",
      benefits: ["Digestive Health", "Immune Function", "Mental Health"],
      mealSuggestion: "Greek yogurt with berries or kefir smoothie with spinach and fruit",
      explanation: "Beneficial bacteria support gut health, which is linked to immune function and mental well-being.",
      activeIngredients: ["Lactobacillus", "Bifidobacterium", "Live cultures"],
      icon: Heart,
      color: "bg-pink-100 text-pink-800"
    },
    {
      id: "fermented-foods",
      name: "Fermented Foods",
      category: "Gut Health",
      benefits: ["Microbiome Support", "Nutrient Absorption", "Inflammation Reduction"],
      mealSuggestion: "Kimchi with rice bowl, sauerkraut with salad, or miso soup",
      explanation: "Fermentation increases nutrient bioavailability and supports a healthy gut microbiome.",
      activeIngredients: ["Beneficial bacteria", "Postbiotics", "Enhanced nutrients"],
      icon: Leaf,
      color: "bg-orange-100 text-orange-800"
    }
  ];

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Longevity Toolkit</h2>
        <p className="text-gray-600">Science-backed food hacks to extend your healthspan</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {foodHacks.map((hack) => {
          const IconComponent = hack.icon;
          return (
            <Card key={hack.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${hack.color}`}>
                    <IconComponent className="w-5 h-5" />
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    {hack.category}
                  </Badge>
                </div>
                <CardTitle className="text-lg">{hack.name}</CardTitle>
              </CardHeader>
              
              <CardContent className="space-y-3">
                <div>
                  <h4 className="font-medium text-sm text-gray-900 mb-1">Benefits</h4>
                  <div className="flex flex-wrap gap-1">
                    {hack.benefits.map((benefit) => (
                      <Badge key={benefit} variant="outline" className="text-xs">
                        {benefit}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-medium text-sm text-gray-900 mb-1">Meal Suggestion</h4>
                  <p className="text-sm text-gray-700">{hack.mealSuggestion}</p>
                </div>

                <div>
                  <h4 className="font-medium text-sm text-gray-900 mb-1">How It Works</h4>
                  <p className="text-xs text-gray-600">{hack.explanation}</p>
                </div>

                <div>
                  <h4 className="font-medium text-sm text-gray-900 mb-1">Active Ingredients</h4>
                  <div className="flex flex-wrap gap-1">
                    {hack.activeIngredients.map((ingredient) => (
                      <span key={ingredient} className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded">
                        {ingredient}
                      </span>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}