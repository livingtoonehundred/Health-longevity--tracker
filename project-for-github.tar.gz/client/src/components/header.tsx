import { Heart } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { User } from "@shared/schema";

export function Header() {
  const { data: user } = useQuery<User>({
    queryKey: ["/api/user"],
  });

  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
              <Heart className="text-white w-4 h-4" />
            </div>
            <h1 className="text-xl font-bold text-gray-900">LifeSpan+</h1>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <a href="#dashboard" className="text-primary font-medium">Dashboard</a>
            <a href="#food" className="text-gray-500 hover:text-gray-700">Nutrition</a>
            <a href="#exercise" className="text-gray-500 hover:text-gray-700">Exercise</a>
            <a href="#sleep" className="text-gray-500 hover:text-gray-700">Sleep</a>
            <a href="#learn" className="text-gray-500 hover:text-gray-700">Learn</a>
          </nav>

          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gray-300 rounded-full"></div>
            <span className="text-sm font-medium text-gray-700">{user?.name || "User"}</span>
          </div>
        </div>
      </div>
    </header>
  );
}
