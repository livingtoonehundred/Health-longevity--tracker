import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertFoodEntrySchema, insertExerciseEntrySchema, insertSleepEntrySchema, insertEatingWindowSchema } from "@shared/schema";
import { z } from "zod";
import { generateFoodInsight, calculateHealthRisks, calculateNutritionScore, analyzeFoodPhoto } from "./ai-service";

function calculateFoodImpact(foodName: string, nutritionScore: number): { hours: number; explanation: string } {
  // Scale from -1 to +3 hours based on nutrition score
  // Score 0-20: -1 to -0.5 hours (harmful foods)
  // Score 20-50: -0.5 to 0 hours (poor choices)
  // Score 50-70: 0 to 1 hours (decent choices)
  // Score 70-100: 1 to 3 hours (excellent choices)
  
  let hours: number;
  let explanation: string;
  
  if (nutritionScore >= 80) {
    hours = 2 + (nutritionScore - 80) / 20; // 2-3 hours
    explanation = "Excellent choice! Rich in antioxidants and essential nutrients that support cellular repair, reduce inflammation, and promote longevity.";
  } else if (nutritionScore >= 60) {
    hours = 1 + (nutritionScore - 60) / 20; // 1-2 hours
    explanation = "Good nutritional choice providing moderate longevity benefits through essential vitamins and minerals.";
  } else if (nutritionScore >= 40) {
    hours = (nutritionScore - 40) / 20; // 0-1 hours
    explanation = "Decent food choice with some nutritional value, but consider adding more nutrient-dense options to your diet.";
  } else if (nutritionScore >= 20) {
    hours = -0.5 + (nutritionScore - 20) / 40; // -0.5 to 0 hours
    explanation = "Poor nutritional choice that may contribute to inflammation and cellular damage. Consider healthier alternatives.";
  } else {
    hours = -1 + nutritionScore / 40; // -1 to -0.5 hours
    explanation = "This food choice may negatively impact longevity through inflammatory compounds and lack of beneficial nutrients.";
  }
  
  return { hours: Math.round(hours * 100) / 100, explanation }; // Round to 2 decimal places
}

function calculateExerciseImpact(exerciseType: string, duration: number, intensity: string): { hours: number; explanation: string } {
  const intensityMultiplier = { low: 1, medium: 1.5, high: 2 }[intensity] || 1;
  const baseBenefit = (duration / 30) * intensityMultiplier; // 30 minutes = 1x multiplier
  
  const explanations = {
    cardio: "Cardiovascular exercise strengthens your heart and improves circulation, adding years to your life",
    strength: "Resistance training builds muscle mass and bone density, crucial for healthy aging",
    flexibility: "Flexibility work maintains mobility and reduces injury risk as you age"
  };
  
  const category = exerciseType.toLowerCase().includes('jog') || exerciseType.toLowerCase().includes('run') ? 'cardio' :
                   exerciseType.toLowerCase().includes('weight') || exerciseType.toLowerCase().includes('strength') ? 'strength' : 'flexibility';
  
  return { hours: baseBenefit, explanation: explanations[category] };
}

function calculateSleepImpact(duration: number, quality: number): { hours: number; explanation: string } {
  const optimalDuration = 8;
  const durationScore = Math.max(0, 1 - Math.abs(duration - optimalDuration) * 0.2);
  const qualityScore = quality / 5;
  const totalScore = (durationScore + qualityScore) / 2;
  
  const baseBenefit = totalScore * 3; // Max 3 hours for perfect sleep
  
  const explanation = quality >= 4 ? 
    "Quality sleep enhances cellular repair, memory consolidation, and immune function" :
    "Improving sleep quality can significantly boost your body's recovery and longevity";
    
  return { hours: baseBenefit, explanation };
}

function calculateEatingWindowImpact(fastingHours: number, eatingWindowHours: number): { hours: number; explanation: string } {
  let impact = 0;
  let explanation = "";

  if (fastingHours >= 16) {
    impact = 2.0;
    explanation = "16+ hour fast activates peak autophagy, maximizes fat oxidation, and triggers growth hormone release for optimal longevity benefits.";
  } else if (fastingHours >= 14) {
    impact = 1.2;
    explanation = "14+ hour fast significantly improves insulin sensitivity, promotes cellular repair, and enhances metabolic flexibility.";
  } else if (fastingHours >= 12) {
    impact = 0.5;
    explanation = "12+ hour fast provides basic metabolic reset, improves digestive health, and supports natural circadian rhythms.";
  } else if (fastingHours >= 10) {
    impact = 0.1;
    explanation = "10+ hour fast offers minimal metabolic benefits but may help with digestive rest.";
  } else {
    impact = -0.5;
    explanation = "Frequent eating (<10h fast) may increase metabolic stress, insulin resistance, and accelerate aging processes.";
  }

  // Additional penalty for very long eating windows (>12 hours)
  if (eatingWindowHours > 12) {
    impact -= 0.3;
    explanation += " Consider shortening eating window for better metabolic health.";
  }

  return {
    hours: Math.round(impact * 10) / 10,
    explanation
  };
}

function calculateBaseLifeExpectancy(onboardingData: any): number {
  // Start with statistical baseline by age and gender
  let baseAge = parseInt(onboardingData.age);
  let lifeExpectancy = onboardingData.gender === 'female' ? 81.2 : 76.4; // US averages
  
  // Calculate genetic longevity based on family history
  const familyAges = [
    onboardingData.grandparent1Age,
    onboardingData.grandparent2Age,
    onboardingData.grandparent3Age,
    onboardingData.grandparent4Age,
    onboardingData.motherAge,
    onboardingData.fatherAge
  ].filter(age => age && parseInt(age) > 0).map(age => parseInt(age));
  
  if (familyAges.length > 0) {
    const averageFamilyAge = familyAges.reduce((sum, age) => sum + age, 0) / familyAges.length;
    
    // Strong genetic component: if family averages high longevity, boost significantly
    if (averageFamilyAge >= 85) {
      lifeExpectancy += 8; // Strong longevity genes
    } else if (averageFamilyAge >= 80) {
      lifeExpectancy += 5; // Good longevity genes
    } else if (averageFamilyAge >= 75) {
      lifeExpectancy += 2; // Average longevity
    } else if (averageFamilyAge < 70) {
      lifeExpectancy -= 3; // Below average family longevity
    }
    
    // Extra bonus for exceptional family longevity (multiple members 85+)
    const longLivedCount = familyAges.filter(age => age >= 85).length;
    if (longLivedCount >= 3) {
      lifeExpectancy += 3; // Exceptional longevity genes
    }
  }
  
  // Adjust based on lifestyle factors from survey
  if (onboardingData.smoker === 'yes') lifeExpectancy -= 10;
  if (onboardingData.smoker === 'former') lifeExpectancy -= 3;
  
  if (onboardingData.exerciseFrequency === 'daily') lifeExpectancy += 3;
  else if (onboardingData.exerciseFrequency === '4-6-times') lifeExpectancy += 2;
  else if (onboardingData.exerciseFrequency === '2-3-times') lifeExpectancy += 1;
  else if (onboardingData.exerciseFrequency === 'rarely') lifeExpectancy -= 2;
  
  if (onboardingData.dietType === 'mediterranean') lifeExpectancy += 2;
  else if (onboardingData.dietType === 'plant-based') lifeExpectancy += 1.5;
  else if (onboardingData.dietType === 'keto') lifeExpectancy += 0.5;
  
  if (onboardingData.alcoholConsumption === 'moderate') lifeExpectancy += 0.5;
  else if (onboardingData.alcoholConsumption === 'heavy') lifeExpectancy -= 3;
  
  if (onboardingData.stressLevel === 'low') lifeExpectancy += 1;
  else if (onboardingData.stressLevel === 'high') lifeExpectancy -= 2;
  
  if (parseInt(onboardingData.sleepHours) >= 7 && parseInt(onboardingData.sleepHours) <= 9) {
    lifeExpectancy += 1;
  } else {
    lifeExpectancy -= 1;
  }
  
  // Disease-specific family history adjustments
  if (onboardingData.familyHistory?.includes('Cardiovascular Disease')) lifeExpectancy -= 2;
  if (onboardingData.familyHistory?.includes('Diabetes')) lifeExpectancy -= 1.5;
  if (onboardingData.familyHistory?.includes('Cancer')) lifeExpectancy -= 1;
  if (onboardingData.familyHistory?.includes('Dementia/Alzheimer\'s')) lifeExpectancy -= 2;
  
  return Math.max(lifeExpectancy, 60); // Minimum reasonable expectancy
}

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get current user
  app.get("/api/user", async (req, res) => {
    try {
      const user = await storage.getUser(1); // Default user for demo
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Save onboarding data and calculate personalized baseline
  app.post("/api/user/onboarding", async (req, res) => {
    try {
      const onboardingData = req.body;
      
      // Calculate personalized baseline life expectancy based on user data
      const baseLifeExpectancy = calculateBaseLifeExpectancy(onboardingData);
      
      // Clear all demo data for fresh start
      await storage.clearUserData(1);
      
      // Update user with personalized data
      const age = parseInt(onboardingData.age) || 48; // fallback to 48 if parsing fails
      const updatedUser = await storage.updateUserProfile(1, {
        name: onboardingData.name || "Your Name",
        age: age,
        gender: onboardingData.gender,
        baseLifeExpectancy: Math.round(baseLifeExpectancy),
        currentLifeExpectancy: Math.round(baseLifeExpectancy),
        totalLifeExtension: 0,
        onboardingData: JSON.stringify(onboardingData)
      });
      
      res.json(updatedUser);
    } catch (error) {
      console.error('Onboarding save error:', error);
      res.status(500).json({ message: "Failed to save onboarding data" });
    }
  });

  // Get dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const userId = 1; // Default user for demo
      
      const todaysFoods = await storage.getTodaysFoodEntries(userId);
      const todaysExercises = await storage.getTodaysExerciseEntries(userId);
      const latestSleep = await storage.getLatestSleepEntry(userId);
      const weeklyExercise = await storage.getWeeklyExerciseStats(userId);
      
      const nutritionScore = todaysFoods.length > 0 ? 
        Math.round(todaysFoods.reduce((sum, food) => sum + food.nutritionScore, 0) / todaysFoods.length) : 0;
      
      const exerciseMinutes = todaysExercises.reduce((sum, exercise) => sum + exercise.duration, 0);
      
      const sleepQuality = latestSleep ? Math.round((latestSleep.quality / 5) * 100) : 0;
      
      res.json({
        nutritionScore,
        exerciseMinutes,
        sleepQuality,
        weeklyExerciseMinutes: weeklyExercise.totalMinutes,
        weeklyCaloriesBurned: weeklyExercise.totalCalories
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Food tracking
  app.post("/api/food", async (req, res) => {
    try {
      // Remove nutritionScore from validation since AI will calculate it
      const baseData = insertFoodEntrySchema.omit({ nutritionScore: true }).parse(req.body);
      
      // AI calculates nutrition score automatically
      const nutritionScore = await calculateNutritionScore(baseData.foodName);
      
      const data = { ...baseData, nutritionScore };
      
      const { hours, explanation } = calculateFoodImpact(data.foodName, data.nutritionScore);
      
      // Get user for AI insight generation
      const user = await storage.getUser(data.userId);
      let aiInsight = explanation;
      
      if (user) {
        try {
          aiInsight = await generateFoodInsight(data.foodName, data.nutritionScore, user.age, user.educationLevel);
        } catch (error) {
          console.log('AI service error:', error);
          console.log('Using fallback explanation due to AI service issue');
        }
      }
      
      const foodEntry = await storage.createFoodEntry({
        ...data,
        lifeImpactHours: hours,
        explanation: aiInsight
      });
      
      // Update user life expectancy
      if (user) {
        const newLifeExpectancy = parseFloat(user.currentLifeExpectancy) + (hours / 8760);
        const newTotalExtension = parseFloat(user.totalLifeExtension || "0") + hours;
        await storage.updateUserLifeExpectancy(data.userId, newLifeExpectancy, newTotalExtension);
      }
      
      res.json(foodEntry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid food entry data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to log food entry" });
      }
    }
  });

  app.get("/api/food", async (req, res) => {
    try {
      const userId = 1; // Default user for demo
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const entries = await storage.getFoodEntries(userId, limit);
      res.json(entries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch food entries" });
    }
  });

  // Exercise tracking
  app.post("/api/exercise", async (req, res) => {
    try {
      const data = insertExerciseEntrySchema.parse(req.body);
      const { hours, explanation } = calculateExerciseImpact(data.exerciseType, data.duration, data.intensity);
      
      const exerciseEntry = await storage.createExerciseEntry({
        ...data,
        lifeImpactHours: hours,
        explanation
      });
      
      // Update user life expectancy
      const user = await storage.getUser(data.userId);
      if (user) {
        const newLifeExpectancy = parseFloat(user.currentLifeExpectancy) + (hours / 8760);
        const newTotalExtension = parseFloat(user.totalLifeExtension || "0") + hours;
        await storage.updateUserLifeExpectancy(data.userId, newLifeExpectancy, newTotalExtension);
      }
      
      res.json(exerciseEntry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid exercise entry data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to log exercise entry" });
      }
    }
  });

  app.get("/api/exercise", async (req, res) => {
    try {
      const userId = 1; // Default user for demo
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const entries = await storage.getExerciseEntries(userId, limit);
      res.json(entries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch exercise entries" });
    }
  });

  // Sleep tracking
  app.post("/api/sleep", async (req, res) => {
    try {
      // Handle simplified sleep data with optional fields
      const simplifiedData = {
        userId: req.body.userId || 1,
        duration: req.body.duration?.toString() || "8",
        quality: req.body.quality || 3,
        sleepTime: req.body.sleepTime || null,
        wakeTime: req.body.wakeTime || null
      };
      
      const data = insertSleepEntrySchema.parse(simplifiedData);
      const { hours, explanation } = calculateSleepImpact(parseFloat(data.duration), data.quality);
      
      const sleepEntry = await storage.createSleepEntry({
        ...data,
        lifeImpactHours: hours,
        explanation
      });
      
      // Update user life expectancy
      const user = await storage.getUser(data.userId);
      if (user) {
        const newLifeExpectancy = parseFloat(user.currentLifeExpectancy) + (hours / 8760);
        const newTotalExtension = parseFloat(user.totalLifeExtension || "0") + hours;
        await storage.updateUserLifeExpectancy(data.userId, newLifeExpectancy, newTotalExtension);
      }
      
      res.json(sleepEntry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid sleep entry data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to log sleep entry" });
      }
    }
  });

  app.get("/api/sleep", async (req, res) => {
    try {
      const userId = 1; // Default user for demo
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const entries = await storage.getSleepEntries(userId, limit);
      res.json(entries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch sleep entries" });
    }
  });

  // Achievements
  app.get("/api/achievements", async (req, res) => {
    try {
      const userId = 1; // Default user for demo
      const achievements = await storage.getAchievements(userId);
      res.json(achievements);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch achievements" });
    }
  });

  // Educational content
  app.get("/api/education", async (req, res) => {
    try {
      const category = req.query.category as string;
      const educationLevel = req.query.educationLevel as string;
      const content = await storage.getEducationalContent(category, educationLevel);
      res.json(content);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch educational content" });
    }
  });

  // Food photo analysis
  app.post("/api/analyze-food-photo", async (req, res) => {
    try {
      const { image } = req.body;
      
      if (!image) {
        return res.status(400).json({ message: "Image data is required" });
      }

      const result = await analyzeFoodPhoto(image);
      res.json(result);
    } catch (error) {
      console.error('Food photo analysis error:', error);
      res.status(500).json({ message: "Failed to analyze food photo" });
    }
  });

  // Eating windows
  app.get("/api/eating-windows", async (req, res) => {
    try {
      const userId = 1; // Default user for demo
      const windows = await storage.getEatingWindows(userId);
      res.json(windows);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch eating windows" });
    }
  });

  app.get("/api/eating-windows/today", async (req, res) => {
    try {
      const userId = 1; // Default user for demo
      const window = await storage.getTodaysEatingWindow(userId);
      res.json(window || null);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch today's eating window" });
    }
  });

  app.post("/api/eating-windows", async (req, res) => {
    try {
      const { firstMealTime, lastMealTime, fastingHours, eatingWindowHours } = req.body;
      
      if (!firstMealTime || !lastMealTime || !fastingHours || !eatingWindowHours) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      // Calculate longevity impact
      const impact = calculateEatingWindowImpact(fastingHours, eatingWindowHours);
      
      const eatingWindow = await storage.createEatingWindow({
        userId: 1,
        firstMealTime,
        lastMealTime,
        fastingHours,
        eatingWindowHours,
        lifeImpactHours: impact.hours,
        explanation: impact.explanation,
      });

      // Update user's life expectancy
      const user = await storage.getUser(1);
      if (user && impact.hours !== 0) {
        const currentLifeExpectancy = parseFloat(user.currentLifeExpectancy);
        const extensionYears = impact.hours / (365 * 24); // Convert hours to years
        const newLifeExpectancy = currentLifeExpectancy + extensionYears;
        const currentExtension = parseFloat(user.totalLifeExtension || "0");
        const newTotalExtension = currentExtension + extensionYears;
        
        await storage.updateUserLifeExpectancy(1, newLifeExpectancy, newTotalExtension);
      }

      res.json(eatingWindow);
    } catch (error) {
      console.error('Eating window creation error:', error);
      res.status(500).json({ message: "Failed to create eating window" });
    }
  });

  // Health risk assessment
  app.get("/api/health-risks", async (req, res) => {
    try {
      const userId = 1; // Default user for demo
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Get recent entries for risk calculation
      const recentFood = await storage.getFoodEntries(userId, 20);
      const recentExercise = await storage.getExerciseEntries(userId, 20);
      const recentSleep = await storage.getSleepEntries(userId, 20);

      const risks = await calculateHealthRisks(user, {
        food: recentFood,
        exercise: recentExercise,
        sleep: recentSleep
      });

      res.json(risks);
    } catch (error) {
      console.error('Health risk assessment error:', error);
      res.status(500).json({ message: "Failed to calculate health risks" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
