import { 
  users, 
  foodEntries, 
  exerciseEntries, 
  sleepEntries, 
  eatingWindows,
  achievements, 
  educationalContent,
  type User, 
  type InsertUser,
  type FoodEntry,
  type InsertFoodEntry,
  type ExerciseEntry,
  type InsertExerciseEntry,
  type SleepEntry,
  type InsertSleepEntry,
  type EatingWindow,
  type InsertEatingWindow,
  type Achievement,
  type EducationalContent
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, gte } from "drizzle-orm";

export interface IStorage {
  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserLifeExpectancy(userId: number, newLifeExpectancy: number, extensionHours: number): Promise<User>;
  updateUserProfile(userId: number, profileData: any): Promise<User>;
  
  // Food tracking
  createFoodEntry(entry: InsertFoodEntry & { lifeImpactHours: number; explanation: string }): Promise<FoodEntry>;
  getFoodEntries(userId: number, limit?: number): Promise<FoodEntry[]>;
  getTodaysFoodEntries(userId: number): Promise<FoodEntry[]>;
  
  // Exercise tracking
  createExerciseEntry(entry: InsertExerciseEntry & { lifeImpactHours: number; explanation: string }): Promise<ExerciseEntry>;
  getExerciseEntries(userId: number, limit?: number): Promise<ExerciseEntry[]>;
  getTodaysExerciseEntries(userId: number): Promise<ExerciseEntry[]>;
  getWeeklyExerciseStats(userId: number): Promise<{ totalMinutes: number; totalCalories: number }>;
  
  // Sleep tracking
  createSleepEntry(entry: InsertSleepEntry & { lifeImpactHours: number; explanation: string }): Promise<SleepEntry>;
  getSleepEntries(userId: number, limit?: number): Promise<SleepEntry[]>;
  getLatestSleepEntry(userId: number): Promise<SleepEntry | undefined>;
  
  // Eating windows
  createEatingWindow(entry: InsertEatingWindow & { lifeImpactHours: number; explanation: string }): Promise<EatingWindow>;
  getEatingWindows(userId: number, limit?: number): Promise<EatingWindow[]>;
  getTodaysEatingWindow(userId: number): Promise<EatingWindow | undefined>;
  
  // Achievements
  createAchievement(userId: number, title: string, description: string, icon: string): Promise<Achievement>;
  getAchievements(userId: number, limit?: number): Promise<Achievement[]>;
  
  // Educational content
  getEducationalContent(category?: string, educationLevel?: string): Promise<EducationalContent[]>;
  
  // Data management
  clearUserData(userId: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    this.seedEducationalContent();
    this.seedDefaultUser();
  }

  private async seedDefaultUser() {
    try {
      const existingUser = await this.getUser(1);
      if (!existingUser) {
        await this.createUser({
          username: "user",
          name: "Your Name",
          age: 48,
          educationLevel: "intermediate",
          baseLifeExpectancy: "77.0",
          currentLifeExpectancy: "77.0", 
          totalLifeExtension: "0.0",
        });
      }
    } catch (error) {
      console.log('Default user seeding will happen after database is ready');
    }
  }

  private async seedEducationalContent() {
    try {
      const existing = await db.select().from(educationalContent).limit(1);
      if (existing.length === 0) {
        const content = [
          {
            title: "Cellular Regeneration",
            description: "Learn how exercise triggers autophagy and cellular renewal processes",
            content: "Exercise stimulates autophagy, a cellular cleaning process that removes damaged proteins and organelles, promoting longevity.",
            category: "exercise",
            educationLevel: "intermediate",
            icon: "dna",
            readTime: 5,
          },
          {
            title: "Antioxidant Power",
            description: "Discover how colorful foods fight free radicals and slow aging",
            content: "Antioxidants in colorful fruits and vegetables neutralize free radicals, reducing oxidative stress and cellular damage.",
            category: "nutrition",
            educationLevel: "basic",
            icon: "leaf",
            readTime: 3,
          },
          {
            title: "Sleep & Memory",
            description: "Understand how quality sleep consolidates memories and repairs brain tissue",
            content: "During deep sleep, the glymphatic system clears metabolic waste from the brain, supporting cognitive health and longevity.",
            category: "sleep",
            educationLevel: "advanced",
            icon: "brain",
            readTime: 4,
          },
        ];
        await db.insert(educationalContent).values(content);
      }
    } catch (error) {
      console.log('Educational content seeding will happen after database is ready');
    }
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUserLifeExpectancy(userId: number, newLifeExpectancy: number, newTotalExtension: number): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) throw new Error("User not found");

    // Calculate current life expectancy from base + accumulated hours
    const baseLifeExpectancy = parseFloat(user.baseLifeExpectancy);
    const calculatedLifeExpectancy = baseLifeExpectancy + (newTotalExtension / 8760);
    
    const [updatedUser] = await db
      .update(users)
      .set({
        currentLifeExpectancy: calculatedLifeExpectancy.toFixed(4),
        totalLifeExtension: newTotalExtension.toFixed(1),
      })
      .where(eq(users.id, userId))
      .returning();
    
    return updatedUser;
  }

  async updateUserProfile(userId: number, profileData: any): Promise<User> {
    const [updatedUser] = await db
      .update(users)
      .set({
        name: profileData.name,
        age: profileData.age,
        gender: profileData.gender,
        baseLifeExpectancy: profileData.baseLifeExpectancy?.toString(),
        currentLifeExpectancy: profileData.currentLifeExpectancy?.toString(),
        totalLifeExtension: profileData.totalLifeExtension?.toString(),
        onboardingData: profileData.onboardingData,
      })
      .where(eq(users.id, userId))
      .returning();
    
    return updatedUser;
  }

  async createFoodEntry(entry: InsertFoodEntry & { lifeImpactHours: number; explanation: string }): Promise<FoodEntry> {
    const [foodEntry] = await db
      .insert(foodEntries)
      .values({
        ...entry,
        lifeImpactHours: entry.lifeImpactHours.toString(),
      })
      .returning();
    return foodEntry;
  }

  async getFoodEntries(userId: number, limit: number = 10): Promise<FoodEntry[]> {
    return await db
      .select()
      .from(foodEntries)
      .where(eq(foodEntries.userId, userId))
      .orderBy(desc(foodEntries.loggedAt))
      .limit(limit);
  }

  async getTodaysFoodEntries(userId: number): Promise<FoodEntry[]> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return await db
      .select()
      .from(foodEntries)
      .where(eq(foodEntries.userId, userId));
  }

  async createExerciseEntry(entry: InsertExerciseEntry & { lifeImpactHours: number; explanation: string }): Promise<ExerciseEntry> {
    const [exerciseEntry] = await db
      .insert(exerciseEntries)
      .values({
        ...entry,
        lifeImpactHours: entry.lifeImpactHours.toString(),
      })
      .returning();
    return exerciseEntry;
  }

  async getExerciseEntries(userId: number, limit: number = 10): Promise<ExerciseEntry[]> {
    return await db
      .select()
      .from(exerciseEntries)
      .where(eq(exerciseEntries.userId, userId))
      .orderBy(desc(exerciseEntries.loggedAt))
      .limit(limit);
  }

  async getTodaysExerciseEntries(userId: number): Promise<ExerciseEntry[]> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return await db
      .select()
      .from(exerciseEntries)
      .where(eq(exerciseEntries.userId, userId));
  }

  async getWeeklyExerciseStats(userId: number): Promise<{ totalMinutes: number; totalCalories: number }> {
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    
    const weeklyEntries = await db
      .select()
      .from(exerciseEntries)
      .where(eq(exerciseEntries.userId, userId));
    
    return {
      totalMinutes: weeklyEntries.reduce((sum: number, entry: any) => sum + entry.duration, 0),
      totalCalories: weeklyEntries.reduce((sum: number, entry: any) => sum + entry.caloriesBurned, 0),
    };
  }

  async createSleepEntry(entry: InsertSleepEntry & { lifeImpactHours: number; explanation: string }): Promise<SleepEntry> {
    const [sleepEntry] = await db
      .insert(sleepEntries)
      .values({
        ...entry,
        lifeImpactHours: entry.lifeImpactHours.toString(),
      })
      .returning();
    return sleepEntry;
  }

  async getSleepEntries(userId: number, limit: number = 10): Promise<SleepEntry[]> {
    return await db
      .select()
      .from(sleepEntries)
      .where(eq(sleepEntries.userId, userId))
      .orderBy(desc(sleepEntries.loggedAt))
      .limit(limit);
  }

  async getLatestSleepEntry(userId: number): Promise<SleepEntry | undefined> {
    const entries = await this.getSleepEntries(userId, 1);
    return entries[0];
  }

  async createEatingWindow(entry: any): Promise<EatingWindow> {
    const [eatingWindow] = await db
      .insert(eatingWindows)
      .values({
        userId: entry.userId,
        firstMealTime: entry.firstMealTime,
        lastMealTime: entry.lastMealTime,
        fastingHours: entry.fastingHours.toString(),
        eatingWindowHours: entry.eatingWindowHours.toString(),
        lifeImpactHours: entry.lifeImpactHours.toString(),
        explanation: entry.explanation,
      })
      .returning();
    return eatingWindow;
  }

  async getEatingWindows(userId: number, limit: number = 10): Promise<EatingWindow[]> {
    return await db
      .select()
      .from(eatingWindows)
      .where(eq(eatingWindows.userId, userId))
      .orderBy(desc(eatingWindows.loggedAt))
      .limit(limit);
  }

  async getTodaysEatingWindow(userId: number): Promise<EatingWindow | undefined> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const [window] = await db
      .select()
      .from(eatingWindows)
      .where(eq(eatingWindows.userId, userId))
      .orderBy(desc(eatingWindows.loggedAt))
      .limit(1);
    
    return window;
  }

  async createAchievement(userId: number, title: string, description: string, icon: string): Promise<Achievement> {
    const [achievement] = await db
      .insert(achievements)
      .values({
        userId,
        title,
        description,
        icon,
      })
      .returning();
    return achievement;
  }

  async getAchievements(userId: number, limit: number = 10): Promise<Achievement[]> {
    return await db
      .select()
      .from(achievements)
      .where(eq(achievements.userId, userId))
      .orderBy(desc(achievements.achievedAt))
      .limit(limit);
  }

  async getEducationalContent(category?: string, educationLevel?: string): Promise<EducationalContent[]> {
    let query = db.select().from(educationalContent);
    
    if (category && educationLevel) {
      return await query
        .where(eq(educationalContent.category, category))
        .where(eq(educationalContent.educationLevel, educationLevel));
    } else if (category) {
      return await query.where(eq(educationalContent.category, category));
    } else if (educationLevel) {
      return await query.where(eq(educationalContent.educationLevel, educationLevel));
    }
    
    return await query;
  }

  // Clear all demo data for a user
  async clearUserData(userId: number): Promise<void> {
    await Promise.all([
      db.delete(foodEntries).where(eq(foodEntries.userId, userId)),
      db.delete(exerciseEntries).where(eq(exerciseEntries.userId, userId)),
      db.delete(sleepEntries).where(eq(sleepEntries.userId, userId)),
      db.delete(eatingWindows).where(eq(eatingWindows.userId, userId)),
      db.delete(achievements).where(eq(achievements.userId, userId))
    ]);
  }
}

export const storage = new DatabaseStorage();
