import Anthropic from '@anthropic-ai/sdk';
import type { TextBlock } from '@anthropic-ai/sdk/resources';

// the newest Anthropic model is "claude-3-7-sonnet-20250219" which was released February 24, 2025
const anthropic = new Anthropic({
  apiKey: "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",
});

export async function calculateNutritionScore(foodName: string): Promise<number> {
  try {
    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219', // the newest Anthropic model is "claude-3-7-sonnet-20250219" which was released February 24, 2025
      max_tokens: 150,
      system: `You are a nutrition expert. Analyze the given food and return ONLY a nutrition score from 1-100 where:
- 1-30: Poor nutritional value (processed foods, junk food, high sugar/trans fats)
- 31-50: Below average (refined foods, moderate nutrition)
- 51-70: Good nutrition (balanced foods, some processing)
- 71-85: Very good (whole foods, nutrient dense)
- 86-100: Excellent (superfoods, optimal nutrition)

Return ONLY the number, no explanation.`,
      messages: [{
        role: 'user',
        content: `Rate the nutrition score for: ${foodName}`
      }]
    });

    const content = response.content[0];
    const scoreText = (content as any).text?.trim() || '';
    const score = parseInt(scoreText);
    
    if (isNaN(score) || score < 1 || score > 100) {
      // Fallback scoring based on food type
      return getFallbackNutritionScore(foodName);
    }
    
    return score;
  } catch (error) {
    console.log('AI nutrition scoring error:', error);
    return getFallbackNutritionScore(foodName);
  }
}

function getFallbackNutritionScore(foodName: string): number {
  const name = foodName.toLowerCase();
  
  // Excellent foods (86-100)
  if (name.includes('blueberr') || name.includes('spinach') || name.includes('salmon') || 
      name.includes('avocado') || name.includes('quinoa') || name.includes('kale') ||
      name.includes('olive oil') || name.includes('nuts') || name.includes('seeds')) {
    return 85 + Math.floor(Math.random() * 15);
  }
  
  // Very good foods (71-85)
  if (name.includes('vegetable') || name.includes('fruit') || name.includes('fish') ||
      name.includes('legume') || name.includes('bean') || name.includes('lentil')) {
    return 71 + Math.floor(Math.random() * 14);
  }
  
  // Good foods (51-70)
  if (name.includes('chicken') || name.includes('egg') || name.includes('rice') ||
      name.includes('pasta') || name.includes('yogurt') || name.includes('cheese')) {
    return 51 + Math.floor(Math.random() * 19);
  }
  
  // Below average (31-50)
  if (name.includes('bread') || name.includes('cereal') || name.includes('snack') ||
      name.includes('processed')) {
    return 31 + Math.floor(Math.random() * 19);
  }
  
  // Poor foods (1-30)
  if (name.includes('candy') || name.includes('soda') || name.includes('pepsi') || name.includes('cola') ||
      name.includes('chips') || name.includes('fries') || name.includes('hot dog') || name.includes('hotdog') ||
      name.includes('fast food') || name.includes('donut') || name.includes('cookie') || name.includes('burger') ||
      name.includes('pizza') || name.includes('fried') || name.includes('ice cream') || name.includes('cake')) {
    return 1 + Math.floor(Math.random() * 29);
  }
  
  // Default moderate score
  return 55;
}

export async function generateFoodInsight(foodName: string, nutritionScore: number, userAge: number, educationLevel: string): Promise<string> {
  try {
    const complexity = educationLevel === 'basic' ? 'simple language' : 
                      educationLevel === 'intermediate' ? 'moderate scientific detail' : 
                      'detailed scientific explanation';

    const prompt = `Explain why "${foodName}" (nutrition score: ${nutritionScore}/100) helps with longevity for a ${userAge}-year-old person. Use ${complexity}. Focus on specific nutrients, cellular mechanisms, and health benefits. Keep it under 100 words.`;

    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 200,
      messages: [
        { role: 'user', content: prompt }
      ],
    });

    const content = response.content[0] as TextBlock;
    return content.text;
  } catch (error) {
    console.error('AI service error:', error);
    return `${foodName} provides essential nutrients that support cellular health and may contribute to longevity through antioxidant activity and metabolic benefits.`;
  }
}

export async function analyzeFoodPhoto(base64Image: string): Promise<{
  foodName: string;
  confidence: number;
  alternatives: string[];
}> {
  try {
    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 300,
      system: `You are a food identification expert. Analyze the image and identify the food items. Return a JSON object with:
{
  "foodName": "primary food item name",
  "confidence": 0.85,
  "alternatives": ["alternative1", "alternative2"]
}
Confidence should be between 0-1. Be specific about the food type and preparation method.`,
      messages: [{
        role: 'user',
        content: [
          {
            type: 'text',
            text: 'Identify the food in this image and provide the response in the specified JSON format.'
          },
          {
            type: 'image',
            source: {
              type: 'base64',
              media_type: 'image/jpeg',
              data: base64Image
            }
          }
        ]
      }]
    });

    const content = response.content[0] as TextBlock;
    const result = JSON.parse(content.text);
    
    return {
      foodName: result.foodName || 'Unknown food',
      confidence: Math.max(0, Math.min(1, result.confidence || 0.5)),
      alternatives: result.alternatives || []
    };
  } catch (error) {
    console.error('Food photo analysis error:', error);
    return {
      foodName: 'Unable to identify food',
      confidence: 0,
      alternatives: ['Please enter food name manually']
    };
  }
}

export async function calculateHealthRisks(user: any, recentEntries: { food: any[], exercise: any[], sleep: any[] }): Promise<{
  cardiovascular: 'low' | 'medium' | 'high';
  diabetes: 'low' | 'medium' | 'high';
  cancer: 'low' | 'medium' | 'high';
  dementia: 'low' | 'medium' | 'high';
  details: {
    cardiovascular: string;
    diabetes: string;
    cancer: string;
    dementia: string;
  };
}> {
  try {
    const avgNutrition = recentEntries.food.length > 0 ? 
      recentEntries.food.reduce((sum, entry) => sum + entry.nutritionScore, 0) / recentEntries.food.length : 50;
    
    const weeklyExercise = recentEntries.exercise.reduce((sum, entry) => sum + entry.duration, 0);
    const avgSleepQuality = recentEntries.sleep.length > 0 ? 
      recentEntries.sleep.reduce((sum, entry) => sum + entry.quality, 0) / recentEntries.sleep.length : 3;

    const prompt = `Based on these health metrics for a ${user.age}-year-old:
- Average nutrition score: ${avgNutrition}/100
- Weekly exercise: ${weeklyExercise} minutes
- Average sleep quality: ${avgSleepQuality}/5

Rate risk levels (low/medium/high) for cardiovascular disease, diabetes, cancer, and dementia. Also provide brief explanations for each risk level and specific recommendations.

Format as JSON:
{
  "cardiovascular": "low|medium|high",
  "diabetes": "low|medium|high", 
  "cancer": "low|medium|high",
  "dementia": "low|medium|high",
  "details": {
    "cardiovascular": "explanation and recommendations",
    "diabetes": "explanation and recommendations",
    "cancer": "explanation and recommendations", 
    "dementia": "explanation and recommendations"
  }
}`;

    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 800,
      messages: [
        { role: 'user', content: prompt }
      ],
    });

    const content = response.content[0] as TextBlock;
    return JSON.parse(content.text);
  } catch (error) {
    console.error('Risk calculation error:', error);
    return {
      cardiovascular: 'medium',
      diabetes: 'medium', 
      cancer: 'medium',
      dementia: 'medium',
      details: {
        cardiovascular: 'Maintain regular exercise and healthy diet to support heart health.',
        diabetes: 'Continue monitoring nutrition and exercise for blood sugar control.',
        cancer: 'Antioxidant-rich foods and regular activity help reduce cancer risk.',
        dementia: 'Good sleep and cognitive activities support brain health.'
      }
    };
  }
}